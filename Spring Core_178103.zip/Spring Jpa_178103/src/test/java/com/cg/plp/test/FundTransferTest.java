package com.cg.plp.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.CustomerExists;
import com.cg.plp.exception.CustomerNotFoundException;
import com.cg.plp.exception.InsufficientBalanceException;
import com.cg.plp.service.BankServiceImpl;
import com.cg.plp.service.BankService;

public class FundTransferTest {

	BankService service = null;

	@Before
	public void setUp() throws Exception {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		service = (BankService) ctx.getBean("service");
	}

	// right inputs
	@Test
	public void checkFundTransfer() {
		try {
			BankAccount customer = service.checkUser("8286703935", "password");
			BankAccount customer2 = service.isValidUser("9892622745");
			String[] result = service.fundTransfer(customer,customer2, 1000);
			for (String r : result) 
				System.out.println(r);
			assertNotNull(result);
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print insufficient balance in console
	@Test
	public void checkFundTransfer2() {
		try {
			BankAccount customer = service.checkUser("8286703935", "password");
			BankAccount customer2 = service.isValidUser("9892622745");
			String[] result = service.fundTransfer(customer,customer2, 9000000);
			assertNotNull(result);
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	//wrong inputs
	//should give no user found
	@Test
	public void checkFundTransfer3() {
		try {
			BankAccount customer = service.checkUser("8286703935", "password");
			BankAccount customer2 = service.isValidUser("111112745");
			String[] result = service.fundTransfer(customer,customer2, 2000);
			assertNotNull(result);
		}catch (CustomerNotFoundException e) {
				System.out.println(e.getMessage()); 
		}catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	@After
	public void destroy() throws Exception {
		service = null;
	}
}
