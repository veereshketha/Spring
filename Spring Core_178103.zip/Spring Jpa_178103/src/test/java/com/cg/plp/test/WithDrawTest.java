package com.cg.plp.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.CustomerExists;
import com.cg.plp.exception.CustomerNotFoundException;
import com.cg.plp.exception.InsufficientBalanceException;
import com.cg.plp.service.BankServiceImpl;
import com.cg.plp.service.BankService;

public class WithDrawTest {
	BankService service = null;

	@Before
	public void setUp() throws Exception {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		service = (BankService) ctx.getBean("service");
	}

	// right inputs
	@Test
	public void checkWithDraw() {
		try {
			BankAccount customer = service.checkUser("8286703935", "password");
			String result = service.withDraw(customer, 2000);
			System.out.println(result);
			assertNotNull(result);
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print insufficient balance in console
	@Test
	public void checkWithDraw2() {
		try {
			BankAccount customer = service.checkUser("8286703935", "password");
			String result = service.withDraw(customer, 9000000);
			System.out.println(result);
			assertNotNull(result);
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
