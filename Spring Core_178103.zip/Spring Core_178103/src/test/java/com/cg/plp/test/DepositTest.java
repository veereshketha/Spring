package com.cg.plp.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.BankAccountExists;
import com.cg.plp.exception.BankAccountNotFoundException;
import com.cg.plp.service.BankServiceImpl;
import com.cg.plp.service.BankService;

public class DepositTest {
	BankService service = null;

	@Before
	public void setUp() throws Exception {
		ApplicationContext context = new ClassPathXmlApplicationContext("annotated.xml");
		service = (BankService) context.getBean("service");
	}

	// right inputs
	@Test
	public void checkDeposit() {
		try {
			BankAccount customer = new BankAccount("Tushar", "t@g.c", "8286703935", "password", 5000);
			service.addAccount(customer);

			String result = service.deposit(customer, 2000);
			assertNotNull(result);
		} catch (BankAccountExists e) {
			System.out.println(e.getMessage());
		} catch (BankAccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print no user as user don't exists in console
	@Test
	public void checkDeposit2() {
		try {
			BankAccount customer = new BankAccount();
			service.addAccount(customer);
			service.checkUser(customer.getMobileNumber(), customer.getPassword());
			String result = service.deposit(customer, 9000);
			assertNotNull(result);
		} catch (BankAccountExists e) {
			System.out.println(e.getMessage());
		} catch (BankAccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
