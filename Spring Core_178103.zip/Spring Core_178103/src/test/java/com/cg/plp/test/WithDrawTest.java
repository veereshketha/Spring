package com.cg.plp.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.BankAccountExists;
import com.cg.plp.exception.BankAccountNotFoundException;
import com.cg.plp.exception.InsufficientBalanceException;
import com.cg.plp.service.BankServiceImpl;
import com.cg.plp.service.BankService;

public class WithDrawTest {
	BankService service = null;

	@Before
	public void setUp() throws Exception {
		ApplicationContext context = new ClassPathXmlApplicationContext("annotated.xml");
		service = (BankService) context.getBean("service");
	}

	// right inputs
	@Test
	public void checkWithDraw() {
		try {
			BankAccount customer = new BankAccount("Tushar", "t@g.c", "8286703935",
					"password", 5000);
			service.addAccount(customer);

			String result = service.withDraw(customer, 2000);
			assertNotNull(result);
		} catch (BankAccountExists e) {
			System.out.println(e.getMessage());
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print insufficient balance in console
	@Test
	public void checkWithDraw2() {
		try {
			BankAccount customer = new BankAccount("Tushar", "t@g.c", "8286703935",
					"password", 5000);
			service.addAccount(customer);
			service.checkUser(customer.getMobileNumber(),
					customer.getPassword());

			String result = service.withDraw(customer, 900000);
			assertNotNull(result);
		} catch (BankAccountExists e) {
			System.out.println(e.getMessage());
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (BankAccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
