package com.cg.plp.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.BankAccountExists;
import com.cg.plp.exception.BankAccountNotFoundException;
import com.cg.plp.exception.InsufficientBalanceException;
import com.cg.plp.service.BankServiceImpl;
import com.cg.plp.service.BankService;

public class FundTransferTest {

	BankService service = null;

	@Before
	public void setUp() throws Exception {
		ApplicationContext context = new ClassPathXmlApplicationContext("annotated.xml");
		service = (BankService) context.getBean("service");
	}

	// right inputs
	@Test
	public void checkFundTransfer() {
		try {
			BankAccount customer = new BankAccount("Tushar", "t@g.c", "8286703935",
					"password", 5000);
			BankAccount customer2 = new BankAccount("Aditya", "a@g.c", "9892622745",
					"password", 5000);
			service.addAccount(customer);
			service.addAccount(customer2);

			String[] result = service.fundTransfer(customer,customer2, 2000);
			assertNotNull(result);
		} catch (BankAccountExists e) {
			System.out.println(e.getMessage());
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (BankAccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print insufficient balance in console
	@Test
	public void checkFundTransfer2() {
		try {
			BankAccount customer = new BankAccount("Tushar", "t@g.c", "8286703935",
					"password", 5000);
			BankAccount customer2 = new BankAccount("Aditya", "a@g.c", "9892622745",
					"password", 5000);
			service.addAccount(customer);
			service.addAccount(customer2);

			String[] result = service.fundTransfer(customer,customer2, 900000);
			assertNotNull(result);
		} catch (BankAccountExists e) {
			System.out.println(e.getMessage());
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (BankAccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	//wrong inputs
	//should give invalid mobile number
	@Test
	public void checkFundTransfer3() {
		try {
			BankAccount customer = new BankAccount("Tushar", "t@g.c", "8286703935",
					"password", 5000);
			
			service.addAccount(customer);
			BankAccount customer2 = service.isValidUser("111111");
			String[] result = service.fundTransfer(customer,customer2, 2000);
			assertNotNull(result);
		} catch (BankAccountExists e) {
			System.out.println(e.getMessage());
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (BankAccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	@After
	public void destroy() throws Exception {
		service = null;
	}
}
