package com.cg.plp.dao;

import java.util.List;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.bean.History;
import com.cg.plp.exception.BankAccountExists;
import com.cg.plp.exception.BankAccountNotFoundException;
import com.cg.plp.exception.InsufficientBalanceException;

public interface BankDao {

	BankAccount addAccount(BankAccount customer) throws BankAccountExists;

	String withDraw(BankAccount customer, double amount)	throws InsufficientBalanceException;

	String deposit(BankAccount customer, double amount) throws BankAccountNotFoundException;

	BankAccount checkUser(String username, String password) throws BankAccountNotFoundException;

	List<History> printTransaction(BankAccount customer);

	BankAccount isValidUser(String mobileNumber) throws BankAccountNotFoundException;
	
	double checkBalance(BankAccount customer);
	
	long CID = 1000;
	int TID = 1;
}
