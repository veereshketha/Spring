package com.cg.plp.ui;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.bean.History;
import com.cg.plp.exception.BankAccountExists;
import com.cg.plp.exception.BankAccountNotFoundException;
import com.cg.plp.exception.IllegalFormatException;
import com.cg.plp.exception.InsufficientBalanceException;
import com.cg.plp.service.BankServiceImpl;
import com.cg.plp.service.BankService;

@Component
public class Main {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("annotated.xml");
		
		// object instantiation
		BankService service = (BankService) context.getBean("service");
		
		Scanner scan = new Scanner(System.in);

		// Asks for Inputs
		for (;;) {
			System.out.println("*************Welcome to Bank************");
			System.out.print("1.Register\t");
			System.out.print("2.Login\t");
			System.out.print("3.Exist\n");
			String choice = "";

			while (true) {
				choice = scan.next();
				try {
					//validate if input between 1-3
					if (service.validateHomeChoice(choice))
						break;
				} catch (IllegalFormatException e) {
					System.out.println(e.getMessage());
				}
			}

			if (choice.equals("1"))// register code
			{
				BankAccount newCustomer = new BankAccount();
				while (true)// take name
				{
					System.out.println("Enter customer name ");
					String temp = scan.next();
					try {
						//validate name
						if (service.validateName(temp)) {
							newCustomer.setName(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}

				while (true)// take email
				{
					System.out.println("Enter email Id");
					String temp = scan.next();
					try {
						//validate email
						if (service.validateEmail(temp)) {
							newCustomer.setEmail(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}

				while (true)// take mobile
				{
					System.out.println("Enter Mobile No");
					String temp = scan.next();
					try {
						//validate mobile number
						if (service.validateMobNo(temp)) {
							newCustomer.setMobileNumber(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}
				while (true)// set password
				{
					System.out.println("Set Password");
					String temp = scan.next();
					try {
						//validate password
						if (service.validatePassword(temp)) {
							newCustomer.setPassword(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}

				// set balance
				newCustomer.setBalance(5000);

				// try to create new user and also checks if user exists
				try {
					BankAccount cust = service.addAccount(newCustomer);
					System.out.println("New Account creted");
					System.out.println(cust);
					cust = new BankAccount();
				} catch (BankAccountExists e) {
					System.out.println(e.getMessage());
				}

			}// end of register
			
			else if (choice.equals("2"))// login code
			{
				BankAccount loggedCustomer = new BankAccount();
				while (true) {
					System.out.println("Enter Mobile no");
					String temp = scan.next();
					System.out.println("Enter Password");
					String pass = scan.next();
					try {
						//get customer from login
						loggedCustomer = service.checkUser(temp, pass);
						break;
					} catch (BankAccountNotFoundException e) {
						System.out.println(e.getMessage());
					}
				}

				while (true)// start submenu
				{
					//System.out.println("Welcome "+loggedCustomer.getName());
					System.out.println("1.Show Balance");
					System.out.println("2.Deposit");
					System.out.println("3.Withdraw");
					System.out.println("4.Fund Transfer");
					System.out.println("5.Print Transactions");
					System.out.println("6.Logout");
					String option = "";
					boolean isLogOut = false;

					while(true)
					{
						option = scan.next();
					try {
						//validate if input between 1-6
						if (service.validateMenuChoice(choice))
							break;
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
					}
					
					switch (option) {
					case "1":
						System.out.println("Balance is Rs."+ service.checkBalance(loggedCustomer));
						break;

					case "2":
						while (true) {
							System.out.println("Enter amount to deposit");
							choice = scan.next();
							try {
								//validate if amount input is valid
								if (service.validateAmount(choice))
									break;
							} catch (IllegalFormatException e) {
								System.out.println(e.getMessage());
							}
						}

						String depositResult="";
						try {
							depositResult = service.deposit(loggedCustomer,
							Double.parseDouble(choice));
						} catch (NumberFormatException e1) {
								System.out.println(e1.getMessage());
						} catch (BankAccountNotFoundException e1) {
							System.out.println(e1.getMessage());
						}
						//print result from server
						System.out.println(depositResult);
						break;

					case "3":
						while (true) {
							System.out.println("Enter amount to withdraw");
							choice = scan.next();
							try {
								//validate if amount input is valid
								if (service.validateAmount(choice))
									break;
							} catch (IllegalFormatException e) {
								System.out.println(e.getMessage());
							}
						}//end of while

						try {
							String withdrawResult = service.withDraw(
									loggedCustomer,
									Double.parseDouble(choice));
							System.out.println(withdrawResult);
						} catch (NumberFormatException
								| InsufficientBalanceException e) {
							System.out.println(e.getMessage());
						}
						break;

					case "4":
						
						String mob="";
						String amt="";
						BankAccount reciever = null;
						while(true)
						{
							System.out.println("Enter mobile number of other user");
							 mob = scan.next();
							System.out.println("Enter the amount");
							 amt = scan.next();
							
							try {
								if(service.validateMobNo(mob) && service.validateAmount(amt))
								{
									reciever = service.isValidUser(mob);
									break;
								}
									
							} catch (IllegalFormatException e) {
								System.out.println(e.getMessage());
							}catch (BankAccountNotFoundException e) {
								System.out.println(e.getMessage());
							}						
						}

						//store fund transfer results
						try {
							String[] data = service.fundTransfer(
									loggedCustomer, reciever,
									Double.parseDouble(amt));
							for (String result : data) {
								System.out.println(result);
							}
						} catch (NumberFormatException
								| InsufficientBalanceException e) {
							System.out.println(e.getMessage());
						} catch (BankAccountNotFoundException e) {
							System.out.println(e.getMessage());
						}
						break;

					case "5":
						List<History> list = 
							service.printTransaction(loggedCustomer);
						System.out.println(list);
						break;

					case "6":
						//logout user
						isLogOut = true;
					default:
						break;
					}

					if (isLogOut) {
						isLogOut = false;
						break;
					} else
						continue;
				}
			}// end of login code
			else { //if choice is 3 ie exit
					System.out.println("**********Thank You**********");
					break;
			}
		}// end of eternal loop
	}
}
