package com.cg.plp.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Repository;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.bean.History;
import com.cg.plp.exception.BankAccountExists;
import com.cg.plp.exception.BankAccountNotFoundException;
import com.cg.plp.exception.InsufficientBalanceException;

@Repository("customerDAO")
public class BankDaoImpl implements BankDao,ApplicationContextAware {

	
	List<BankAccount> database;
	List<History> transactionDB;
	long cid = CID;
	int tid = TID;
	
	@Autowired
	private ApplicationContext context;

	public BankDaoImpl() {
		database = new ArrayList<>();
		transactionDB = new ArrayList<>();
	}

	@Override
	public BankAccount addAccount(BankAccount customer) throws BankAccountExists {
		// check if user exists
		// count should be 0
		long count = database.stream().filter(x -> x.getMobileNumber().equals(customer.getMobileNumber())).count();
		if (count < 1) {
			// add customer
			customer.setCustomerId(++cid);
			database.add(customer);

			// store its first transaction
			History recordTrans = (History) context.getBean(History.class);
			recordTrans.setTid(++tid);
			recordTrans.setMobileNo(customer.getMobileNumber());
			recordTrans.setType("CR");
			recordTrans.setAmount(customer.getBalance());
			recordTrans.setBalance(customer.getBalance());
			transactionDB.add(recordTrans);
			return customer;
		} else
			// if customer exists then throw error
			throw new BankAccountExists("User Already Exists");
	}

	@Override
	public String withDraw(BankAccount customer, double amount) throws InsufficientBalanceException {
		// withdraw logic
		// minimum balance should be atleast Rs.100
		if (amount <= customer.getBalance() - 100) {
			customer.setBalance(customer.getBalance() - amount);

			// store transaction history
			History recordTrans = (History) context.getBean(History.class);
			recordTrans.setTid(++tid);
			recordTrans.setMobileNo(customer.getMobileNumber());
			recordTrans.setType("DB");
			recordTrans.setAmount(amount);
			recordTrans.setBalance(customer.getBalance());
			transactionDB.add(recordTrans);
			// return success data in string format
			return "Rs." + amount + " debited from account " + customer.getCustomerId() + " on " + LocalDateTime.now()
					+ "\nNew Balance is Rs." + customer.getBalance();
		} else
			// throws exception if balance is below 1000
			// will be cached by service class
			throw new InsufficientBalanceException("You Have Insufficient Amount.");
	}

	@Override
	public String deposit(BankAccount customer, double amount) throws BankAccountNotFoundException {
		try {
			customer.setBalance(customer.getBalance() + amount);
			// store transaction history
			History recordTrans = (History) context.getBean(History.class);
			recordTrans.setTid(++tid);
			recordTrans.setMobileNo(customer.getMobileNumber());
			recordTrans.setType("CR");
			recordTrans.setAmount(amount);
			recordTrans.setBalance(customer.getBalance());
			transactionDB.add(recordTrans);
			// return success data in string format
			return "Rs." + amount + " credited on account " + customer.getCustomerId() + " on " + LocalDateTime.now()
					+ "\nNew Balance is Rs." + customer.getBalance();
		} catch (Exception e) {
			// if user not found
			throw new BankAccountNotFoundException("Invalid Mobile Number");
		}
	}

	@Override
	public BankAccount checkUser(String username, String password) throws BankAccountNotFoundException {

		// to login
		// check username which is mobile number and password
		try {
			BankAccount customer = database.stream()
					.filter(x -> x.getMobileNumber().equals(username) && x.getPassword().equals(password)).findFirst()
					.get();
			return customer;
		} catch (Exception e) {

			// if invalid credentials
			throw new BankAccountNotFoundException("No User Found");
		}
	}

	@Override
	public List<History> printTransaction(BankAccount customer) {
		// create a list to return transaction history of a user
		List<History> summaryList = new ArrayList<History>();

		// find summary of the user
		summaryList = transactionDB
						.stream()
						.filter(x -> x.getMobileNo().equals(customer.getMobileNumber()))
						.collect(Collectors.toList());

		return summaryList;
	}

	@Override
	public BankAccount isValidUser(String mobileNumber) throws BankAccountNotFoundException {

		try {
			// find customer
			BankAccount customer = database.stream().filter(x -> x.getMobileNumber().equals(mobileNumber)).findFirst()
					.get();
			return customer;
		} catch (Exception e) {
			// if user not found
			throw new BankAccountNotFoundException("Invalid Mobile Number");
		}
	}

	@Override
	public double checkBalance(BankAccount customer) {
		return customer.getBalance();
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.context = applicationContext;
		
	}

}
