package com.cg.plp.service;

import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.bean.History;
import com.cg.plp.dao.BankDaoImpl;
import com.cg.plp.dao.BankDao;
import com.cg.plp.exception.BankAccountExists;
import com.cg.plp.exception.BankAccountNotFoundException;
import com.cg.plp.exception.IllegalFormatException;
import com.cg.plp.exception.InsufficientBalanceException;


@Service("service")
public class BankServiceImpl implements BankService {

	//object instantiation 
	@Autowired
	BankDao customerDAO;

	//withdraw amount
	//minimum balance should be 100
	@Override
	public String withDraw(BankAccount customer, double amount) throws InsufficientBalanceException{
		try {
			return customerDAO.withDraw(customer, amount);
		} catch (InsufficientBalanceException e) {
			throw new InsufficientBalanceException(e.getMessage());
		}
	}

	//deposit amount in wallet
	@Override
	public String deposit(BankAccount customer, double amount) throws BankAccountNotFoundException{
		try {
			return customerDAO.deposit(customer, amount);
		} catch (Exception e) {
			throw new BankAccountNotFoundException(e.getMessage());
		}
	}

	//store withdraw result and deposit result in array
	@Override
	public String[] fundTransfer(BankAccount fromCust, BankAccount toCust, double amount) throws InsufficientBalanceException, BankAccountNotFoundException {
		
		String[] result = new String[2];
		try
		{
			result[0] = customerDAO.withDraw(fromCust, amount);
			result[1] = customerDAO.deposit(toCust, amount);
			return result;
		}catch(InsufficientBalanceException e)
		{
			throw new InsufficientBalanceException(e.getMessage());
		}
		catch(BankAccountNotFoundException e)
		{
			//if wrong mobile number
			throw new BankAccountNotFoundException(e.getMessage());
		}
	
		
	}

	//returns records in list
	@Override
	public List<History> printTransaction(BankAccount customer) {
		return customerDAO.printTransaction(customer);
	}

	//create user
	@Override
	public BankAccount addAccount(BankAccount customer) throws BankAccountExists{
		try {
			return customerDAO.addAccount(customer);
		} catch (BankAccountExists e) {
			throw new BankAccountExists(e.getMessage());
		}
	}

	//login method
	@Override
	public BankAccount checkUser(String username, String password) throws BankAccountNotFoundException{
		try {
			return customerDAO.checkUser(username, password);
		} catch (BankAccountNotFoundException e) {
			throw new BankAccountNotFoundException(e.getMessage());
		}
	}
	
	@Override
	public double checkBalance(BankAccount customer) {
		return customerDAO.checkBalance(customer);
	}
	@Override
	public boolean validateName(String name) throws IllegalFormatException{
		if(name.matches(userNamePattern))
			return true;
		else
			throw new IllegalFormatException("name should be between 2 - 9 letters with 1st letter capital");
		
	}

	@Override
	public boolean validateMobNo(String mobileno)  throws IllegalFormatException{
		if(mobileno.matches(usermobilePattern))
			return true;
		else
			throw new IllegalFormatException("Enter Valid 10 digit mobile number.");
	}

	@Override
	public boolean validateEmail(String email)  throws IllegalFormatException{
		if(email.matches(useremailPattern))
			return true;
		else
			throw new IllegalFormatException("Enter Valid Email");
	}

	@Override
	public boolean validatePassword(String password)  throws IllegalFormatException{
		if(password.matches(userpasswordPattern))
			return true;
		else
			throw new IllegalFormatException("Enter atleast 6-12 character");
	}

	@Override
	public boolean validateHomeChoice(String userHChoice)  throws IllegalFormatException{
		if(userHChoice.matches(userHomeChoice))
			return true;
		else
			throw new IllegalFormatException("Please choose 1 or 2 or 3");
	}

	@Override
	public boolean validateAmount(String useramt)  throws IllegalFormatException{
		if(useramt.matches(userAmount))
			return true;
		else
			throw new IllegalFormatException("Enter in numbers and should be more than Rs.10");
	}

	@Override
	public boolean validateMenuChoice(String userMChoice)
			throws IllegalFormatException {
		if(userMChoice.matches(userMenuChoice))
			return true;
		else
			throw new IllegalFormatException("Please choose between 1 - 6");
	}

	@Override
	public BankAccount isValidUser(String mobileNumber)
			throws BankAccountNotFoundException {
		try
		{
			return customerDAO.isValidUser(mobileNumber);			
		}catch(BankAccountNotFoundException e)
		{
			throw new BankAccountNotFoundException(e.getMessage());
		}

	}
}
