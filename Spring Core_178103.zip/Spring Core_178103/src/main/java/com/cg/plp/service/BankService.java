package com.cg.plp.service;

import java.util.List;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.bean.History;
import com.cg.plp.exception.BankAccountExists;
import com.cg.plp.exception.BankAccountNotFoundException;
import com.cg.plp.exception.IllegalFormatException;
import com.cg.plp.exception.InsufficientBalanceException;

public interface BankService {

	String userNamePattern="[A-Z]{1}[a-z]{2,9}";
	String usermobilePattern=("(0/91)?[7-9][0-9]{9}");
	String useremailPattern="[a-zA-Z0-9+_.-]+@(.+)$";
	String userpasswordPattern="[a-zA-Z0-9,.@_]{6,12}";
	String userHomeChoice="[1-3]{1}";
	String userMenuChoice="[1-6]{1}";
	String userAmount="[0-9]{2,10}";
	
	 boolean validateName(String name) throws IllegalFormatException;
	 boolean validateMobNo(String mobileno) throws IllegalFormatException;
	 boolean validateEmail(String email) throws IllegalFormatException;
	 boolean validatePassword(String password) throws IllegalFormatException;
	 boolean validateHomeChoice(String userHChoice) throws IllegalFormatException;
	 boolean validateMenuChoice(String userHChoice) throws IllegalFormatException;
	 boolean validateAmount(String useramt) throws IllegalFormatException;
	 
	String withDraw(BankAccount customer,double amount) throws InsufficientBalanceException;
	
	String deposit(BankAccount customer,double amount) throws BankAccountNotFoundException;
	
	String[] fundTransfer(BankAccount fromCust,BankAccount toCust,double amount) throws InsufficientBalanceException,BankAccountNotFoundException;
	
	List<History> printTransaction(BankAccount customer);
	
	BankAccount addAccount(BankAccount customer) throws BankAccountExists;
	
	BankAccount checkUser(String username, String password) throws BankAccountNotFoundException;
	
	double checkBalance(BankAccount customer);
	
	BankAccount isValidUser(String mobileNumber) throws BankAccountNotFoundException;
	
}
