package com.cg.plp.exception;

public class BankAccountExists extends Exception{

	public BankAccountExists() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankAccountExists(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
