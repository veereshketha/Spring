package com.cg.plp.service;

import java.sql.SQLException;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.dao.BankDAO;
import com.cg.plp.dao.BankDAOImpl;
import com.cg.plp.exception.BankingException;

public class BankingServiceImpl implements BankingService {
	
	BankDAO dao=new BankDAOImpl();

	@Override
	public void validateName(String custName) throws BankingException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, custName)) {
			throw new BankingException("First letter should be capital and length must be in between 5 to 10");
		}
		
	}

	@Override
	public void validateMobileNo(String mobileNo) throws BankingException {
		String nameRegEx = "[7|8|9]{1}[0-9]{9}";
		if(!Pattern.matches(nameRegEx, mobileNo)) {
			throw new BankingException("mobile number should be 10 digits");
		}
	}

	@Override
	public void validateAdharNo(String adharNo) throws BankingException {
		String nameRegEx = "[0-9]{12}";
		if (!Pattern.matches(nameRegEx, String.valueOf(adharNo))) {
			throw new BankingException("Adhar Number must be digits: ");
		}
		
	}

	@Override
	public void addBankAccountDetails(int accno, BankAccount ab) throws ClassNotFoundException, SQLException {
		dao.addBankAccountDetails(accno,ab);
		
	}

	@Override
	public BankAccount showbalance(int number) throws ClassNotFoundException, SQLException, BankingException {
		
		BankAccount answer=dao.showbalance(number);
		return answer;
		
	}

	@Override
	public BankAccount getAccountDetails(int target) throws ClassNotFoundException, SQLException, BankingException {
		
		return dao.getAccountDetails(target);
	}

	@Override
	public BankAccount getWithdraw(int acc1) throws SQLException, ClassNotFoundException, BankingException {
		
		return dao.getWithdraw(acc1);
	}

	@Override
	public void getAccountToAdded(double total, int target) throws ClassNotFoundException, SQLException, BankingException {
		
		dao.getAccountToAdded(total,target);
		
	}

	@Override
	public void getDetailsForWithdraw(double d1, int acc1) throws SQLException, ClassNotFoundException {
		
		dao.getDetailsForWithdraw(d1,acc1);
		
	}

	@Override
	public void storeIntoTransaction(String s, Integer i) {
		dao.storeIntoTransaction(s,i);
		
	}

	@Override
	public Map<String, Integer> getTransactionInfo() {
		
		Map<String,Integer>ans=dao.getTransactionInfo();
				
		return ans;
	}

}
