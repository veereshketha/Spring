package com.cg.plp.service;

import java.sql.SQLException;
import java.util.Map;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.BankingException;

public interface BankingService {

	void validateName(String custName) throws BankingException;

	void validateMobileNo(String mobileNo) throws BankingException;

	void validateAdharNo(String adharNo) throws BankingException;

	void addBankAccountDetails(int accountnumber, BankAccount account) throws BankingException, ClassNotFoundException, SQLException;

	BankAccount showbalance(int number) throws BankingException, ClassNotFoundException, SQLException;

	BankAccount getAccountDetails(int target)throws BankingException, ClassNotFoundException, SQLException;

	BankAccount getWithdraw(int acc1)throws BankingException, SQLException, ClassNotFoundException;

	void getAccountToAdded(double total, int target) throws ClassNotFoundException, SQLException, BankingException;

	void getDetailsForWithdraw(double d1, int acc1) throws SQLException, ClassNotFoundException;

	void storeIntoTransaction(String s, Integer i);

	Map<String, Integer> getTransactionInfo();

	

}
