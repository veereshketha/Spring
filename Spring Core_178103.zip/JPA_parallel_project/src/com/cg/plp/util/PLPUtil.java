package com.cg.plp.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PLPUtil {
	
	public static EntityManager entity() {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Bank");
		EntityManager factory=emf.createEntityManager();
		return factory;
	}

}
