package com.cg.exception;

public class PLPException extends Exception {
	
	public PLPException(String s) {
		
		super(s);
	}

}
