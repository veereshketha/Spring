package com.cg.dao;

import java.util.Map;
import com.cg.bean.BankAccount;
import com.cg.exception.PLPException;

public interface BankDAO {

	void addcustomer(BankAccount ab);

	BankAccount showbalance(int acc) throws PLPException;

	Map<String, Integer> getTransactionInfo()throws PLPException;

	void storeIntoTransaction(String s, Integer i)throws PLPException;

	void getAccountDetails(double total, int target)throws PLPException;

	void getWithdraw(double money, int acc1)throws PLPException;
	
	

}
