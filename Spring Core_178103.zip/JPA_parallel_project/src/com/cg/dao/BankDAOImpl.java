package com.cg.dao;

import java.util.HashMap;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.bean.BankAccount;
import com.cg.exception.PLPException;

public class BankDAOImpl implements BankDAO {
	
	public static Map<String,Integer>map=new HashMap<String,Integer>();
	
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA_parallel_project");
	EntityManager entityManager=emf.createEntityManager();

	@Override
	public void addcustomer(BankAccount ab) {
		
		entityManager.getTransaction().begin();
		entityManager.persist(ab);
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}

	@Override
	public BankAccount showbalance(int acc) throws PLPException {
		
		entityManager.getTransaction().begin();
		BankAccount account=entityManager.find(BankAccount.class, acc);
		return account;
	}

	@Override
	public Map<String, Integer> getTransactionInfo() throws PLPException {	
		return map;
	}

	@Override
	public void storeIntoTransaction(String s, Integer i) throws PLPException {
		map.put(s, i);
	}

	@Override
	public void getAccountDetails(double total, int target)throws PLPException {
		
		entityManager.getTransaction().begin();
		BankAccount account=entityManager.find(BankAccount.class, target);
		double d=account.getBalance();
		account.setBalance(total+d);
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		System.out.print("balance updated in account after withdrawn: "+(total+d));
	}

	@Override
	public void getWithdraw(double money, int acc1) throws PLPException {
		
		entityManager.getTransaction().begin();
		BankAccount account=entityManager.find(BankAccount.class,acc1);
		double d1=account.getBalance();
		if(d1>money) {
		account.setBalance(money+d1);
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		System.out.print("balance updated in account after withdrawn: "+(d1-money));
		}
		else
			throw new PLPException("InSufficient Balance");
	}

	}



