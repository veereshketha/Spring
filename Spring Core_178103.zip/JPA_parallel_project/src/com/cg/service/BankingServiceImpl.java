package com.cg.service;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.bean.BankAccount;
import com.cg.dao.BankDAO;
import com.cg.dao.BankDAOImpl;
import com.cg.exception.PLPException;


public class BankingServiceImpl implements BankingService {
	
	BankDAO dao=new BankDAOImpl();

	@Override
	public void addcustomer(BankAccount ab) {
		dao.addcustomer(ab);	
	}

	@Override
	public BankAccount showbalance(int number) throws PLPException {
		BankAccount answer=dao.showbalance(number);
		return answer;
	}

	@Override
	public void validateAdharNo(String adharNo) throws PLPException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, adharNo)) {
			throw new PLPException("first letter should be capital and length must be in between 5 to 10");
		}	
	}

	@Override
	public void validateMobileNo(String mobileNo) throws PLPException {
		String nameRegEx = "[7|8|9]{1}[0-9]{9}";
		if(!Pattern.matches(nameRegEx, mobileNo)) {
			throw new PLPException("mobile number should be 10 digits");
		}
	}

	@Override
	public void validateName(String customerName) throws PLPException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, customerName)) {
			throw new PLPException("first letter should be capital and length must be in between 5 to 10");
		}
		
	}

	@Override
	public Map<String, Integer> getTransactionInfo() throws PLPException {
		
		return dao.getTransactionInfo();
	}

	@Override
	public void storeIntoTransaction(String s, Integer i) throws PLPException {
		dao.storeIntoTransaction(s,i);
	}

	@Override
	public void getAccountDetails(double total, int target) throws PLPException {
		dao.getAccountDetails(total,target);
	}

	@Override
	public void getWithdraw(double money, int acc1) throws PLPException {
		dao.getWithdraw(money,acc1);
		
	}



	

}
