package com.cg.service;

import java.util.Map;
import com.cg.bean.BankAccount;
import com.cg.exception.PLPException;

public interface BankingService {


	void addcustomer(BankAccount ab)throws PLPException;

	BankAccount showbalance(int number)throws PLPException;

	void validateAdharNo(String adharNo)throws PLPException;

	void validateMobileNo(String cellno)throws PLPException;

	void validateName(String custName)throws PLPException;

	Map<String, Integer> getTransactionInfo() throws PLPException;

	void storeIntoTransaction(String s, Integer i)throws PLPException;

	void getAccountDetails(double total, int target) throws PLPException;

	void getWithdraw(double money, int acc1) throws PLPException;

	

	

	
	

	

	
	
	
	
	
	

}
