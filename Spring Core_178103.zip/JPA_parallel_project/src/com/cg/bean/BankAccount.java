package com.cg.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Accountt")
public class BankAccount implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	//@GeneratedValue(strategy =GenerationType.AUTO)
	private int accno;
	private String customerName;
	private String mobileNo;
	private String adharNo;
	private double balance;
	public BankAccount() {
		
	}
	public BankAccount(int accno, String customerName, String mobileNo, String adharNo, double balance) {
		super();
		this.accno = accno;
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.balance = balance;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(String adharNo) {
		this.adharNo = adharNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance =balance;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "BankAccount [accno=" + accno + ", customerName=" + customerName + ", mobileNo=" + mobileNo
				+ ", adharNo=" + adharNo + ",balance=" + balance + "]";
	}
	
	
	
	

}
