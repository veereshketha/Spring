package com.cg.ui;

import java.util.InputMismatchException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Scanner;
import com.cg.bean.BankAccount;
import com.cg.exception.PLPException;
import com.cg.service.BankingService;
import com.cg.service.BankingServiceImpl;

public class Main {
	
	public static void main(String args[]) throws PLPException 
	{
		Scanner scanner = null;
		BankingService bank=new BankingServiceImpl();
		BankAccount account=new BankAccount();
		String continueChoice = "";

		do {

			System.out.println("Welcome to Bank");
			System.out.println("Select Your Choice");
			System.out.println("1. Create Account");
			System.out.println("2. Show Balance ");
			System.out.println("3. Deposit ");
			System.out.println("4. Withdraw ");
			System.out.println("5. Fund Transfer");
			System.out.println("7. Exit");
		
			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					switch (choice) {
					
					//For creating account
					
					case 1:
						String customerName = "";
						boolean customerNameFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter customer name");
							try {
								customerName = scanner.nextLine();
							bank.validateName(customerName);
							customerNameFlag = true;
							break;
							}
							 catch (PLPException e) {
							 customerNameFlag = false;
							 System.err.println(e.getMessage());
							}
						} while (!customerNameFlag);

						String mobileNo= "";
						boolean cellnoFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile Number: ");
							try {
								mobileNo = scanner.nextLine();
								bank.validateMobileNo(mobileNo);
								cellnoFlag = true;
								break;
							}catch (PLPException e) {
								cellnoFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!cellnoFlag);
						

						String adharNo=null;
						boolean adharNoFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter adhar number: ");
							try {
								adharNo = scanner.nextLine();
								bank.validateAdharNo(adharNo);
								adharNoFlag = true;
								break; 
							}catch (PLPException e) {
								adharNoFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!adharNoFlag);
						
						double balance=0;
						boolean accountFlag=false;
						do {
						scanner = new Scanner(System.in);
						System.out.println("Enter Account balance: ");
						try {
						balance=scanner.nextInt();
						accountFlag=true;
						}catch(InputMismatchException e) {
							accountFlag=false;
							System.err.println("Balance should be only digits");
						}
						}while(!accountFlag);
						int accNo = (int) (Math.random() * 1000000);
						int ifsc_code = (int) (Math.random() * 1000);
						account.setBalance(balance);
						account.setAdharNo(adharNo);
						account.setMobileNo(mobileNo);
						account.setCustomerName(customerName);
						account.setAccno(accNo);
						bank.addcustomer(account);
						System.out.println("Account Created");
						System.out.println("Name: " +customerName);
						System.out.println("adharNo: "+adharNo);
						System.out.println("Mobile No: "+mobileNo);
						System.out.println("Account number: " +accNo);
						System.out.println("ifsc_code is:"+ifsc_code);
						System.out.println("Account Balance: "+balance);
						break;
						
						//For balance Enquiry
						
					case 2:
					{	
						int acc=0;
						boolean accflag=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number To Get The Balance");
						try {
						acc=scanner.nextInt();
						BankAccount ab=bank.showbalance(acc);
						accflag=true;
						}catch(InputMismatchException e) {
						 accflag=false;
						 System.err.println("Account number should be only digits");
						}catch(PLPException e) {
						 accflag=false;
						 System.err.println(e.getMessage());
							
						}
						}while(!accflag);
						break;
					}
					
					//For depositing amount
					
					case 3:
					{
						double deposit=0;
						boolean depositflag=false; 
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Amount to be deposited: ");
							try {
								deposit=scanner.nextDouble();
								depositflag=true;
							}catch(InputMismatchException e) {
								depositflag=false;
								System.err.println("Deposit Amount should be only digits");
							}
						}while(!depositflag);
						
						int target=0;
						boolean targetflag=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Account number of the Amount to deposit: ");
							try {
								target=scanner.nextInt();
								bank.getAccountDetails(deposit,target);
								targetflag=true;
							}catch(InputMismatchException e) {
								targetflag=false;
								System.err.println("Account number should be in digits");
							}
						}while(!targetflag);		
						break;
					}
					
					//For withdrawing amount
					
					case 4:
					{
						
						double money=0;
						boolean moneyflag=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Amount to withdraw");
							try {
								money=scanner.nextDouble();
								moneyflag=true;
							}catch(InputMismatchException e) {
								moneyflag=false;
								System.err.println("Amount should be only digits");
							}
						}while(!moneyflag);
						
						
						int acc1=0;
						boolean accflag1=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number To withdraw money: ");
						try {
						acc1=scanner.nextInt();
						bank.getWithdraw(money,acc1);
						accflag1=true;
						}catch(InputMismatchException e) {
							accflag1=false;
							System.err.println("Account number should be only digits");
						}catch(PLPException e) {
							accflag1=false;
							System.err.println(e.getMessage());
						}
						}while(!accflag1);
						
						break;
					}
					
					//For Fund transfer
					
					case 5:
					{
						double money1=0;
						boolean moneyflag1=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Amount to transfer: ");
							try {
								money1=scanner.nextDouble();
								moneyflag1=true;
							}catch(InputMismatchException e) {
								moneyflag1=false;
								System.err.println("Amount should be only digits");
							}
						}while(!moneyflag1);
						
						int acc2=0;
						boolean accflag2=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number from which money to be transferred: ");
						try {
						acc2=scanner.nextInt();
						BankAccount de=bank.showbalance(acc2);
						double d3=de.getBalance();
						double d4=d3-money1;
						System.out.println("Updated balance in the sender account: "+d4);
						accflag2=true;
						}catch(InputMismatchException e) {
							accflag2=false;
							System.err.println("Account number should be only digits");
						}catch(PLPException e) {
							accflag2=false;
							System.err.println(e.getMessage());
							
						}
						}while(!accflag2);
						
						int acc3=0;
						boolean accflag3=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number to which money to be transferred: ");
						try {
						acc3=scanner.nextInt();
						BankAccount ef=bank.showbalance(acc3);
						double d5=ef.getBalance();
						double d6=d5+money1;
						System.out.println("Updated balance in the Receiver account: "+d6);
						accflag3=true;
						}catch(InputMismatchException e) {
							accflag3=false;
							System.err.println("Input should be digits");
						}catch(PLPException e) {
							accflag3=false;
							System.err.println(e.getMessage());	
						}
						}while(!accflag3);
						break;
					}
					
					
					//Exit from the system
					
				      case 7:
							System.out.println("Thank you");
							System.exit(0);
							break;

						default:
							choiceFlag = false;
							System.out.println("Input should be 1,2,3,4,5,6 or 7");
							break;
						}
				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}
}