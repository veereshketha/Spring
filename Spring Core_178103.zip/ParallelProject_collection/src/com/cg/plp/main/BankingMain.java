package com.cg.plp.main;

import java.util.InputMismatchException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Scanner;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.PLPException;
import com.cg.plp.service.BankingService;
import com.cg.plp.service.BankingServiceImpl;

public class BankingMain {
	
	public static void main(String args[]) throws PLPException 
	{
		Scanner scanner = null;
		BankingService bank=new BankingServiceImpl();
		BankAccount account=new BankAccount();
		String continueChoice = "";

		do {

			System.out.println("**********welcome to bank**************");
			System.out.println("Select Your Choice");
			System.out.println("1. Create Account");
			System.out.println("2. Show Balance  ");
			System.out.println("3. Deposit ");
			System.out.println("4. Withdraw ");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transactions");
			System.out.println("7. Exit");
		
			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					switch (choice) {
					
					//For creating account
					
					case 1:
						String customerName = "";
						boolean customerNameFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter customer name");
							try {
								customerName = scanner.nextLine();
							bank.validateName(customerName);
							customerNameFlag = true;
							break;
							}
							 catch (PLPException e) {
							 customerNameFlag = false;
							 System.err.println(e.getMessage());
							}
						} while (!customerNameFlag);

						String mobileNo= "";
						boolean mobileNoFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile Number: ");
							try {
								mobileNo = scanner.nextLine();
								bank.validateMobileNo(mobileNo);
								mobileNoFlag = true;
								break;
							}catch (PLPException e) {
								mobileNoFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mobileNoFlag);
						

						String adharNo=null;
						boolean adharNoFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter AdharNo: ");
							try {
								adharNo = scanner.nextLine();
								bank.validateAdharNo(adharNo);
								adharNoFlag = true;
								break; 
							}catch (PLPException e) {
								adharNoFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!adharNoFlag);
						
							
						account.setCustomerName(customerName);
						account.setMobileNo(mobileNo);
						account.setAdharNo(adharNo);
						
						double balance=0;
						boolean accountFlag=false;
						do {
						scanner = new Scanner(System.in);
						System.out.println("Enter balance: ");
						try {
						balance=scanner.nextInt();
						accountFlag=true;
						}catch(InputMismatchException e) {
							accountFlag=false;
							System.err.println("Balance should be only digits");
						}
						}while(!accountFlag);
						account.setBalance(balance);
						int accountnumber = (int) (Math.random()*10000000);
						bank.addBankAccountDetails(accountnumber,account);
						System.out.println("Account should be Created maintain minimum balance");
						System.out.println("Name: " +customerName);
						System.out.println("AdharNumber: "+adharNo);
						System.out.println("Mobile No: "+mobileNo);
						System.out.println("Account number: " +accountnumber);
						System.out.println("Balance: "+balance);
						break;
						
						//For balance Enquiry
						
					case 2:
					{	
						int accNo=0;
						boolean accflag=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number:");
						try {
						accNo=scanner.nextInt();
						BankAccount ab=bank.showbalance(accNo);
						System.out.println("the current balance in your account is: "+ab.getBalance());
						String bal="The balance in your Account is: ";
						Integer i=(int) ab.getBalance();
						bank.storeIntoTransaction(bal,i);
						accflag=true;
						}catch(InputMismatchException e) {
						 accflag=false;
						 System.err.println("Account number should be only digits");
						}catch(PLPException e) {
						 accflag=false;
						 System.err.println(e.getMessage());
							
						}
						}while(!accflag);
						break;
					}
					
					//For depositing amount
					
					case 3:
					{
						double deposit=0;
						boolean depositflag=false; 
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Amount: ");
							try {
								deposit=scanner.nextDouble();
								depositflag=true;
							}catch(InputMismatchException e) {
								depositflag=false;
								System.err.println("Amount should be only digits");
							}
						}while(!depositflag);
						
						int target=0;
						boolean targetflag=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Account number of concern account holder: ");
							try {
								target=scanner.nextInt();
								BankAccount bc=bank.getAccountDetails(target);
								System.out.println("current balance in the account is: "+bc.getBalance());
								double add=bc.getBalance();
								double total=add+deposit;
								bc.setBalance(total);
								String s1="The balance in the Deposited Account is ";
								Integer i1=(int) add;
								bank.storeIntoTransaction(s1,i1);
								System.out.println("Updated balance is: "+total);
								String s7="The Updated balance after Deposited concern yesAccount is ";
								Integer i7=(int)total;
								bank.storeIntoTransaction(s7,i7);
								targetflag=true;
							}catch(InputMismatchException e) {
								targetflag=false;
								System.err.println("Account number should be in digits");
							}
						}while(!targetflag);		
						break;
					}
					
					//For withdrawing amount
					
					case 4:
					{
						
						double money=0;
						boolean moneyflag=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Amount to withdraw");
							try {
								money=scanner.nextDouble();
								moneyflag=true;
							}catch(InputMismatchException e) {
								moneyflag=false;
								System.err.println("Amount should be only digits");
							}
						}while(!moneyflag);
						
						
						int acc1=0;
						boolean accflag1=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number To withdraw money: ");
						try {
						acc1=scanner.nextInt();
						BankAccount cd=bank.getWithdraw(acc1);
						double d=cd.getBalance();
						System.out.println("Present balance in the account is: "+d);
						if(d>money) {
							double d1=account.setBalance(d-money);
							System.out.println("Updated balance in the account is: "+d1);
							String s3="The balance in the withdraw Account is ";
							Integer i3=(int) cd.getBalance();
							bank.storeIntoTransaction(s3,i3);
							String s8="The Updated balance in the withdraw Account is ";
							Integer i8=(int) d1;
							bank.storeIntoTransaction(s8,i8);
						}
						else {
							System.out.println("Insufficient balance");
						}
						accflag1=true;
						}catch(InputMismatchException e) {
							accflag1=false;
							System.err.println("Account number should be only digits");
						}catch(PLPException e) {
							accflag1=false;
							System.err.println(e.getMessage());
							
						}
						}while(!accflag1);
						
						break;
					}
					
					//For Fund transfer
					
					case 5:
					{
						double money1=0;
						boolean moneyflag1=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Amount to transfer: ");
							try {
								money1=scanner.nextDouble();
								moneyflag1=true;
							}catch(InputMismatchException e) {
								moneyflag1=false;
								System.err.println("Amount should be only digits");
							}
						}while(!moneyflag1);
						
						int acc2=0;
						boolean accflag2=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number from which account to be transferred: ");
						try {
						acc2=scanner.nextInt();
						BankAccount de=bank.showbalance(acc2);
						double d3=de.getBalance();
						String s9="The balance in the Sender Account is ";
						Integer i9=(int) d3;
						bank.storeIntoTransaction(s9,i9);
						double d4=d3-money1;
						System.out.println("Updated balance in the sender account: "+d4);
						String s4="The Updated balance in the Sender Account is ";
						Integer i4=(int)d4;
						bank.storeIntoTransaction(s4,i4);
						accflag2=true;
						}catch(InputMismatchException e) {
							accflag2=false;
							System.err.println("Account number should be only digits");
						}catch(PLPException e) {
							accflag2=false;
							System.err.println(e.getMessage());
							
						}
						}while(!accflag2);
						
						int acc3=0;
						boolean accflag3=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number to which account to be transferred: ");
						try {
						acc3=scanner.nextInt();
						BankAccount ef=bank.showbalance(acc3);
						double d5=ef.getBalance();
						String s10="The balance in the Receiver Account is ";
						Integer i10=(int) d5;
						bank.storeIntoTransaction(s10,i10);
						double d6=d5+money1;
						System.out.println("Updated balance in the Receiver account: "+d6);
						String s5="The Updated balance in the sender Account from Receiver Account is ";
						Integer i5=(int) d6;
						bank.storeIntoTransaction(s5,i5);
						accflag3=true;
						}catch(InputMismatchException e) {
							accflag3=false;
							System.err.println("Input should be digits");
						}catch(PLPException e) {
							accflag3=false;
							System.err.println(e.getMessage());
							
						}
						}while(!accflag3);
						break;
					}
					
					//For printing transactions
					
					case 6:
					{
						Map<String,Integer>map=bank.getTransactionInfo();
						for (Entry<String, Integer> entry : map.entrySet()) {
						    System.out.println( entry.getKey()+""+ entry.getValue());
						}
						break;
					}
					
					//Exit from the system
					
				      case 7:
							System.out.println("*************Thank you***************");
							System.exit(0);
							break;

						default:
							choiceFlag = false;
							System.out.println("Input should be 1,2,3,4,5,6 or 7");
							break;
						}
				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}
}