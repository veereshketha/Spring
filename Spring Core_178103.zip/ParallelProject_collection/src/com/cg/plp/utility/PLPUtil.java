package com.cg.plp.utility;

import java.util.HashMap;
import java.util.Map;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.PLPException;

public class PLPUtil {
	
	static HashMap<Integer,BankAccount> account=new HashMap<Integer,BankAccount>();
	static Map<String,Integer> trans=new HashMap<String,Integer>();
	
	static {
		account.put(1, new BankAccount("krishna","7013752882","chennai",10000));
		account.put(2, new BankAccount("kalyan","8951582421","bangalore",40000));
		account.put(3, new BankAccount("nanba","9052235533","hyderabad",35000));
		account.put(4, new BankAccount("arun","8008667199","mumbai",51000));
	}
	
	public static void addcustomer(Integer i, BankAccount account1) {
		account.put(i, account1); 
	}

	public static HashMap<Integer, BankAccount> getAllDetials() {
	    return account;
		}

	public static Map<String, Integer> getTrans() {
		return trans;
	}

	public static void setTrans(Map<String, Integer> trans) {
		PLPUtil.trans = trans;
	}
	
	public static void addTransaction(String s,Integer I) {
		trans.put(s, I);
	}

	public static BankAccount showbalance(int number) throws PLPException
	{
		if(account.containsKey(number))
		{
			BankAccount answer=account.get(number);
			return answer;
		}
		else
			throw new PLPException("Invalid Account");
	}
	
	public static BankAccount getAccountToAdd(int target) throws PLPException
	{
		if(account.containsKey(target))
		{
			BankAccount ans=account.get(target);
			return ans;
		}
		else
			throw new PLPException("Invalid Account");
	}

	public static BankAccount getDetailsForWithdraw(int acc1) throws PLPException {
		
		if(account.containsKey(acc1))
		{
			BankAccount ans=account.get(acc1);
			return ans;
		}
		else
			throw new PLPException("Invalid Account");
	}
	
	

}
