package com.cg.plp.service;

import java.util.Map;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.PLPException;

public interface BankingService {


	void addBankAccountDetails(int accno, BankAccount ab)throws PLPException;

	BankAccount showbalance(int number)throws PLPException;

	void validateAdharNo(String adharNo)throws PLPException;

	void validateMobileNo(String mobileNo)throws PLPException;

	void validateName(String customerName)throws PLPException;

	BankAccount getAccountDetails(int target) throws PLPException;

	BankAccount getWithdraw(int acc1) throws PLPException;

	Map<String, Integer> getTransactionInfo() throws PLPException;

	void storeIntoTransaction(String bal, Integer i)throws PLPException;

	

	
	

	

	
	
	
	
	
	

}
