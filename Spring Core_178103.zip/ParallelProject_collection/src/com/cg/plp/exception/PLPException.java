package com.cg.plp.exception;

public class PLPException extends Exception {
	
	public PLPException(String s) {
		super(s);
	}

}
