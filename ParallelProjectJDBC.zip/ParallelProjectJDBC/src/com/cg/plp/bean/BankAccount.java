package com.cg.plp.bean;

public class BankAccount {
	
	private String customerName;
	private String mobileNo;
	private String adharNo;
	private double balance;
	
	public BankAccount() 
	{

	}

	public BankAccount(String customerName, String mobileNo, String adharNo, double balance) {
		super();
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.balance = balance;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAdharNo() {
		return adharNo;
	}

	public void setAdharNo(String adharNo) {
		this.adharNo = adharNo;
	}

	public double getBalance() {
		return balance;
	}

	public double setBalance(double balance) {
		return this.balance = balance;
	}

	@Override
	public String toString() {
		return "BankAccount [customerName=" + customerName + ", mobileNo=" + mobileNo + ", adharNo=" + adharNo
				+ ", balance=" + balance + "]";
	}

	 
}
