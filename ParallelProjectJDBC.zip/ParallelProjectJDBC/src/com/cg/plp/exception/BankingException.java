package com.cg.plp.exception;

public class BankingException extends Exception {
	
	public BankingException(String s)
	{
		super(s);
	}

}
