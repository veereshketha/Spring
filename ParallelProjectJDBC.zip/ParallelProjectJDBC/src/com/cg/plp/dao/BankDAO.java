package com.cg.plp.dao;

import java.sql.SQLException;
import java.util.Map;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.BankingException;

public interface BankDAO {

	BankAccount showbalance(int number) throws SQLException, ClassNotFoundException, BankingException;

	void addBankAccountDetails(int accno, BankAccount ab) throws ClassNotFoundException, SQLException;

	BankAccount getAccountDetails(int target) throws ClassNotFoundException, SQLException, BankingException;

	BankAccount getWithdraw(int acc1) throws SQLException, ClassNotFoundException, BankingException;

	void getAccountToAdded(double total, int target) throws ClassNotFoundException, SQLException, BankingException;

	void getDetailsForWithdraw(double d1, int acc1) throws SQLException, ClassNotFoundException;

	void storeIntoTransaction(String s, Integer i);

	Map<String, Integer> getTransactionInfo();

}
