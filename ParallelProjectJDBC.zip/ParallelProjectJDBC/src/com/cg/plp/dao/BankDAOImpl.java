package com.cg.plp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.BankingException;
import com.cg.plp.util.PLPUtil;

public class BankDAOImpl implements BankDAO {
	
	public static Map<String,Integer>map=new HashMap<String,Integer>();

	@Override
	public BankAccount showbalance(int number) throws SQLException,ClassNotFoundException, BankingException {
		
		Connection con=PLPUtil.connect();
		Statement st=con.createStatement();
		ResultSet res=st.executeQuery("SELECT * FROM ACCOUNT WHERE ACCOUNTNO=' "+number+" ' ");
		
		while(res.next())
		{
			int accno=res.getInt(1);
			String custName=res.getString(2);
			String branchname=res.getString(4);
		    String cellno=res.getString(3);
			double accountbalance =res.getDouble(5);
			BankAccount ab=new BankAccount(custName,cellno,branchname,accountbalance);
			return ab;		
	}
		con.commit();
		throw new BankingException("Invalid account number");
	}

	@Override
	public void addBankAccountDetails(int accno, BankAccount ab) throws ClassNotFoundException, SQLException {
		Connection con=PLPUtil.connect();
		Statement st=con.createStatement();
		PreparedStatement pst=con.prepareStatement("INSERT INTO ACCOUNT VALUES(?,?,?,?,?)");
		pst.setInt(1, accno);
		pst.setString(2, ab.getCustomerName());
		pst.setString(3, ab.getMobileNo());
		pst.setString(4, ab.getAdharNo());
		pst.setDouble(5, ab.getBalance());
		pst.executeUpdate();
		
	}

	@Override
	public BankAccount getAccountDetails(int target) throws ClassNotFoundException, SQLException, BankingException {
		
		Connection con=PLPUtil.connect();
		Statement st=con.createStatement();
		ResultSet res2 =st.executeQuery("SELECT * FROM ACCOUNT WHERE ACCOUNTNO=' "+target+" ' "); 
			 
		while(res2.next())
		{
			int accno=res2.getInt(1);
			String custName=res2.getString(2);
			String branchname=res2.getString(4);
		    String cellno=res2.getString(3);
			double accountbalance =res2.getDouble(5);
			BankAccount ab=new BankAccount(custName,cellno,branchname,accountbalance);
			return ab;		
	}
		con.commit();
		throw new BankingException("Invalid account number");
	}

	@Override
	public BankAccount getWithdraw(int acc1) throws SQLException, ClassNotFoundException, BankingException {
		
		Connection con=PLPUtil.connect();
		Statement st=con.createStatement();
		ResultSet res5 =st.executeQuery("SELECT * FROM ACCOUNT WHERE ACCOUNTNO=' "+acc1+" ' "); 
			 
		while(res5.next())
		{
			int accno=res5.getInt(1);
			String custName=res5.getString(2);
			String branchname=res5.getString(4);
		    String cellno=res5.getString(3);
			double accountbalance =res5.getDouble(5);
			BankAccount ab=new BankAccount(custName,cellno,branchname,accountbalance);
			return ab;		
	}
		con.commit();
		throw new BankingException("Invalid account number");
	}

	@Override
	public void getAccountToAdded(double total, int target) throws ClassNotFoundException, SQLException, BankingException {
	
		Connection con=PLPUtil.connect();
		Statement st=con.createStatement();
		ResultSet res3 =st.executeQuery("update ACCOUNT set ACCOUNTBALANCE='"+total+"'where ACCOUNTNO='"+target+"'"); 
		con.commit();
	}
	

	@Override
	public void getDetailsForWithdraw(double d1, int acc1) throws SQLException, ClassNotFoundException {
		
		Connection con=PLPUtil.connect();
		Statement st=con.createStatement();
		ResultSet res4 =st.executeQuery("update ACCOUNT set ACCOUNTBALANCE='"+d1+"'where ACCOUNTNO='"+acc1+"'"); 	 
		con.commit();
	}

	@Override
	public void storeIntoTransaction(String s, Integer i) {
		
		map.put(s, i);
	}

	@Override
	public Map<String, Integer> getTransactionInfo() {
		
		return map;
	}

}
