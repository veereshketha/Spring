package com.cg.plp.service;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.dao.BankDAO;
import com.cg.plp.dao.BankDAOImpl;
import com.cg.plp.exception.PLPException;


public class BankingServiceImpl implements BankingService {
	
	BankDAO dao=new BankDAOImpl();

	@Override
	public void addBankAccountDetails(int accno, BankAccount ab) {
		dao.addBankAccountDetails(accno,ab);	
	}

	@Override
	public BankAccount showbalance(int accNo) throws PLPException {
		BankAccount answer=dao.showbalance(accNo);
		return answer;
	}

	@Override
	public void validateAdharNo(String adharNo) throws PLPException {
		String nameRegEx = "[0-9]{12}";
		if (!Pattern.matches(nameRegEx, String.valueOf(adharNo))) {
			throw new PLPException("Adhar number should be 12 digits:");
		}	
	}

	@Override
	public void validateMobileNo(String mobileNo) throws PLPException {
		String nameRegEx = "[7|8|9]{1}[0-9]{9}";
		if(!Pattern.matches(nameRegEx, mobileNo)) {
			throw new PLPException("mobile number should be 10 digits");
		}
	}

	@Override
	public void validateName(String customerName) throws PLPException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, customerName)) {
			throw new PLPException("first letter should be capital and length must be in between 5 to 10");
		}
		
	}

	@Override
	public BankAccount getAccountDetails(int target) throws PLPException {
		
		return dao.getAccountDetails(target);
		
		
	}

	@Override
	public BankAccount getWithdraw(int acc1) throws PLPException {
		
		return dao.getWithdraw(acc1);
	}

	@Override
	public Map<String, Integer> getTransactionInfo() throws PLPException {
		
		return dao.getTransactionInfo();
	}

	@Override
	public void storeIntoTransaction(String bal, Integer i) throws PLPException {
		dao.storeIntoTransaction(bal,i);
	}

	

}
