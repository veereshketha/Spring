package com.cg.plp.dao;

import java.util.Map;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.PLPException;
import com.cg.plp.utility.PLPUtil;

public class BankDAOImpl implements BankDAO {

	@Override
	public void addBankAccountDetails(int accno, BankAccount ab) {
		PLPUtil.addcustomer(accno, ab);
		
	}

	@Override
	public BankAccount showbalance(int accNo) throws PLPException {
		BankAccount answer=PLPUtil.showbalance(accNo);
		return answer;
	}

	@Override
	public BankAccount getAccountDetails(int target) throws PLPException {
		
		return PLPUtil.getAccountToAdd(target);
	}

	@Override
	public BankAccount getWithdraw(int acc1) throws PLPException {
		
		return PLPUtil.getDetailsForWithdraw(acc1);
	}

	@Override
	public Map<String, Integer> getTransactionInfo() throws PLPException {
	
		return PLPUtil.getTrans();
	}

	@Override
	public void storeIntoTransaction(String s, Integer i) throws PLPException {
		PLPUtil.addTransaction(s, i);
	}
	
	
	

}
