package com.cg.plp.dao;

import java.util.Map;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.PLPException;

public interface BankDAO {

	void addBankAccountDetails(int accno, BankAccount ab);

	BankAccount showbalance(int accNo) throws PLPException;

	BankAccount getAccountDetails(int target) throws PLPException;

	BankAccount getWithdraw(int acc1)throws PLPException;

	Map<String, Integer> getTransactionInfo()throws PLPException;

	void storeIntoTransaction(String s, Integer i)throws PLPException;
	
	

}
