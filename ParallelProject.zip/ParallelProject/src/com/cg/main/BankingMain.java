package com.cg.main;

import java.util.InputMismatchException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Scanner;
import com.cg.bean.Account;
import com.cg.exception.BankingException;
import com.cg.service.BankingService;
import com.cg.service.BankingServiceImpl;

public class BankingMain {
	
	public static void main(String args[]) throws BankingException 
	{
		Scanner scanner = null;
		BankingService bank=new BankingServiceImpl();
		Account account=new Account();
		String continueChoice = "";

		do {

			System.out.println("-----------------------------WELCOME------------------------------------");
			System.out.println("Select Your Choice");
			System.out.println("1. Create Account");
			System.out.println("2. Balance Enquiry ");
			System.out.println("3. Deposit Amount");
			System.out.println("4. Withdraw Cash");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transactions");
			System.out.println("7. Exit");
		
			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					switch (choice) {
					
					//For creating account
					
					case 1:
						String custName = "";
						boolean custNameFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter customer name");
							try {
							custName = scanner.nextLine();
							bank.validateName(custName);
							custNameFlag = true;
							break;
							}
							 catch (BankingException e) {
							 custNameFlag = false;
							 System.err.println(e.getMessage());
							}
						} while (!custNameFlag);

						String cellno= "";
						boolean cellnoFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Cell Number: ");
							try {
								cellno = scanner.nextLine();
								bank.validateCell(cellno);
								cellnoFlag = true;
								break;
							}catch (BankingException e) {
								cellnoFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!cellnoFlag);
						

						String branchname=null;
						boolean branchnameFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Branch name: ");
							try {
								branchname = scanner.nextLine();
								bank.validateBranch(branchname);
								branchnameFlag = true;
								break; 
							}catch (BankingException e) {
								branchnameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!branchnameFlag);
						
							
						account.setCustName(custName);
						account.setCellno(cellno);
						account.setBranch(branchname);
						
						double accountbalance=0;
						boolean accountFlag=false;
						do {
						scanner = new Scanner(System.in);
						System.out.println("Enter Account balance: ");
						try {
						accountbalance=scanner.nextInt();
						accountFlag=true;
						}catch(InputMismatchException e) {
							accountFlag=false;
							System.err.println("Balance should be only digits");
						}
						}while(!accountFlag);
						account.setBalance(accountbalance);
						int accountnumber = (int) (Math.random() * 1000);
						bank.addcustomer(accountnumber,account);
						System.out.println("Account Created");
						System.out.println("Name: " +custName);
						System.out.println("Branch: "+branchname);
						System.out.println("Mobile No: "+cellno);
						System.out.println("Account number: " +accountnumber);
						System.out.println("Account Balance: "+accountbalance);
						break;
						
						//For balance Enquiry
						
					case 2:
					{	
						int acc=0;
						boolean accflag=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number To Get The Balance");
						try {
						acc=scanner.nextInt();
						Account ab=bank.showbalance(acc);
						System.out.println("the balance in your account is: "+ab.getBalance());
						String s="The balance in your Account is: ";
						Integer i=(int) ab.getBalance();
						bank.storeIntoTransaction(s,i);
						accflag=true;
						}catch(InputMismatchException e) {
						 accflag=false;
						 System.err.println("Account number should be only digits");
						}catch(BankingException e) {
						 accflag=false;
						 System.err.println(e.getMessage());
							
						}
						}while(!accflag);
						break;
					}
					
					//For depositing amount
					
					case 3:
					{
						double deposit=0;
						boolean depositflag=false; 
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Amount to be deposited: ");
							try {
								deposit=scanner.nextDouble();
								depositflag=true;
							}catch(InputMismatchException e) {
								depositflag=false;
								System.err.println("Deposit Amount should be only digits");
							}
						}while(!depositflag);
						
						int target=0;
						boolean targetflag=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Account number of the Amount to deposit: ");
							try {
								target=scanner.nextInt();
								Account bc=bank.getAccountToAdd(target);
								System.out.println("Present balance in the account is: "+bc.getBalance());
								double add=bc.getBalance();
								double total=add+deposit;
								bc.setBalance(total);
								String s1="The balance in the Deposited Account is ";
								Integer i1=(int) add;
								bank.storeIntoTransaction(s1,i1);
								System.out.println("Updated balance is: "+total);
								String s7="The Updated balance in the Deposited Account is ";
								Integer i7=(int)total;
								bank.storeIntoTransaction(s7,i7);
								targetflag=true;
							}catch(InputMismatchException e) {
								targetflag=false;
								System.err.println("Account number should be in digits");
							}
						}while(!targetflag);		
						break;
					}
					
					//For withdrawing amount
					
					case 4:
					{
						
						double money=0;
						boolean moneyflag=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Amount to withdraw");
							try {
								money=scanner.nextDouble();
								moneyflag=true;
							}catch(InputMismatchException e) {
								moneyflag=false;
								System.err.println("Amount should be only digits");
							}
						}while(!moneyflag);
						
						
						int acc1=0;
						boolean accflag1=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number To withdraw money: ");
						try {
						acc1=scanner.nextInt();
						Account cd=bank.getDetailsForWithdraw(acc1);
						double d=cd.getBalance();
						System.out.println("Present balance in the account is: "+d);
						if(d>money) {
							double d1=account.setBalance(d-money);
							System.out.println("Updated balance in the account is: "+d1);
							String s3="The balance in the withdraw Account is ";
							Integer i3=(int) cd.getBalance();
							bank.storeIntoTransaction(s3,i3);
							String s8="The Updated balance in the withdraw Account is ";
							Integer i8=(int) d1;
							bank.storeIntoTransaction(s8,i8);
						}
						else {
							System.out.println("Insufficient balance");
						}
						accflag1=true;
						}catch(InputMismatchException e) {
							accflag1=false;
							System.err.println("Account number should be only digits");
						}catch(BankingException e) {
							accflag1=false;
							System.err.println(e.getMessage());
							
						}
						}while(!accflag1);
						
						break;
					}
					
					//For Fund transfer
					
					case 5:
					{
						double money1=0;
						boolean moneyflag1=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Amount to transfer: ");
							try {
								money1=scanner.nextDouble();
								moneyflag1=true;
							}catch(InputMismatchException e) {
								moneyflag1=false;
								System.err.println("Amount should be only digits");
							}
						}while(!moneyflag1);
						
						int acc2=0;
						boolean accflag2=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number from which money to be transferred: ");
						try {
						acc2=scanner.nextInt();
						Account de=bank.showbalance(acc2);
						double d3=de.getBalance();
						String s9="The balance in the Sender Account is ";
						Integer i9=(int) d3;
						bank.storeIntoTransaction(s9,i9);
						double d4=d3-money1;
						System.out.println("Updated balance in the sender account: "+d4);
						String s4="The Updated balance in the Sender Account is ";
						Integer i4=(int)d4;
						bank.storeIntoTransaction(s4,i4);
						accflag2=true;
						}catch(InputMismatchException e) {
							accflag2=false;
							System.err.println("Account number should be only digits");
						}catch(BankingException e) {
							accflag2=false;
							System.err.println(e.getMessage());
							
						}
						}while(!accflag2);
						
						int acc3=0;
						boolean accflag3=false;
						do {
					    scanner=new Scanner(System.in);
						System.out.println("Enter Your Account Number to which money to be transferred: ");
						try {
						acc3=scanner.nextInt();
						Account ef=bank.showbalance(acc3);
						double d5=ef.getBalance();
						String s10="The balance in the Receiver Account is ";
						Integer i10=(int) d5;
						bank.storeIntoTransaction(s10,i10);
						double d6=d5+money1;
						System.out.println("Updated balance in the Receiver account: "+d6);
						String s5="The Updated balance in the Receiver Account from Sender Account is ";
						Integer i5=(int) d6;
						bank.storeIntoTransaction(s5,i5);
						accflag3=true;
						}catch(InputMismatchException e) {
							accflag3=false;
							System.err.println("Input should be digits");
						}catch(BankingException e) {
							accflag3=false;
							System.err.println(e.getMessage());
							
						}
						}while(!accflag3);
						break;
					}
					
					//For printing transactions
					
					case 6:
					{
						Map<String,Integer>map=bank.getTransactionInfo();
						for (Entry<String, Integer> entry : map.entrySet()) {
						    System.out.println( entry.getKey()+""+ entry.getValue());
						}
						break;
					}
					
					//Exit from the system
					
				      case 7:
							System.out.println("---------------------Thank you------------------------------- ");
							System.exit(0);
							break;

						default:
							choiceFlag = false;
							System.out.println("Input should be 1,2,3,4,5,6 or 7");
							break;
						}
				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}
}