package com.cg.pp.dto;

public class Customer {
	
	private String customerName;
	private String customerNo;
	private int customerAge;
	private long accNo;
	public Customer() {
		
	}
	public Customer(String customerName, String customerNo, int customerAge, long accNo) {
		
		this.customerName = customerName;
		this.customerNo = customerNo;
		this.customerAge = customerAge;
		this.accNo = accNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
	public int getCustomerAge() {
		return customerAge;
	}
	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", customerNo=" + customerNo + ", customerAge=" + customerAge
				+ ", accNo=" + accNo + "]";
	}
	
	

}
