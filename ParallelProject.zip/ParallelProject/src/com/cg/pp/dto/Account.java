package com.cg.pp.dto;

import java.time.LocalDate;

public class Account {
	
	private double balance;
	private long accNo;
	private LocalDate date;
	public Account() {
		
	}
	public Account(double balance, long accNo, LocalDate date) {
		
		this.balance = balance;
		this.accNo = accNo;
		this.date = date;
	}
public Account(double balance, long accNo) {
		
		this.balance = balance;
		this.accNo = accNo;
		
	}
	
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getAccno() {
		return accNo;
	}
	public void setAccno(long accNo) {
		this.accNo = accNo;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Account [balance=" + balance + ", accno=" + accNo + ", date=" + date + "]";
	}
	
	

}
