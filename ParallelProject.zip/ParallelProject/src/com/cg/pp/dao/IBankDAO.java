package com.cg.pp.dao;

import java.sql.SQLException;
import java.util.HashMap;

import com.cg.pp.dto.Account;
import com.cg.pp.dto.Customer;

public interface IBankDAO {
	
	public long addcustDetails(long accno,Customer cus ) throws ClassNotFoundException, SQLException;
	
	public long addAccDetails(long accno,Account acc) throws ClassNotFoundException, SQLException;
	
	public Account showBalance(Long accNo) throws ClassNotFoundException, SQLException;
	
	public Account deposit(Long accNo,double bal) throws ClassNotFoundException, SQLException;
	
	public Account withDraw(Long accNo,double bal) throws ClassNotFoundException, SQLException;
	
	public Account fundTransfer(Long accNo) throws ClassNotFoundException, SQLException;
	
	
	
	public  HashMap<Long,Account> fetchAccount() throws ClassNotFoundException, SQLException;
}
