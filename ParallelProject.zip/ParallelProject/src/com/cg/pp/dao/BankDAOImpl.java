package com.cg.pp.dao;

import java.sql.SQLException;
import com.cg.pp.util.Jdbc;
import java.sql.Statement;
import java.time.LocalDate;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import com.cg.pp.exceptions.BankException;
import com.cg.pp.dto.Account;
import com.cg.pp.dto.Customer;

public class BankDAOImpl implements IBankDAO {

	@Override
	public long addcustDetails(long accno,Customer cus ) throws ClassNotFoundException, SQLException {
		Connection c=Jdbc.connect();
		Statement s=c.createStatement();
		PreparedStatement pst=c.prepareStatement("INSERT INTO Customer VALUES(?,?,?,?)");
		
		pst.setString(1, cus.getCustomerName());
		pst.setString(2, cus.getCustomerNo());
		pst.setInt(3, cus.getCustomerAge());
		pst.setDouble(4, cus.getAccNo());
		pst.executeUpdate();
		return 0;
	}
	

	@Override
	public Account showBalance(Long accNo) throws ClassNotFoundException, SQLException {
		Connection con=Jdbc.connect();
		Statement st=con.createStatement();
		ResultSet res=st.executeQuery("SELECT * FROM ACCOUNT WHERE ACCOUNTNO=' "+accNo+" ' ");
		
		while(res.next())
		{
			int accno=res.getInt(1);
			long accNo1=res.getLong(2);
			
		    
			double balance =res.getDouble(5);
			Account ab=new Account(balance,accNo1);
			return ab;		
	}
		con.commit();
		return null;
	}


	@Override
	public Account deposit(Long accNo,double bal) throws ClassNotFoundException, SQLException {
		
		Connection c=Jdbc.connect();
		Statement stmt2=c.createStatement();
		ResultSet res=stmt2.executeQuery("SELECT * FROM ACCOUNT WHERE ACCNO=' "+accNo+" ' ");
		while(res.next())
		{
			int accno=res.getInt(1);
			double balance=res.getDouble(2);
			long accNo2=res.getLong(3);
			
		    
			Account a=new Account(balance,accNo);
			return a;		
		}
		c.commit();
		return null;
		
	
	}

	/*@Override
	public Account withDraw(Long accNo,double bal) throws ClassNotFoundException, SQLException {
		Connection c=Jdbc.connect();
		Statement stmt=c.createStatement();
		ResultSet res1 =stmt.executeQuery("update ACCOUNT set balance='"+res1+"'where ACCNO='"+accNo+"'"); 	 
		c.commit();
		
	}*/

	/*@Override
	public Account fundTransfer(Long accNo) throws ClassNotFoundException, SQLException {
Account account=	Utility.fundTransferDetails(accNo);
return account;
		
	}*/



	@Override
	public long addAccDetails(long accno, Account acc) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public HashMap<Long, Account> fetchAccount() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Account fundTransfer(Long accNo) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Account withDraw(Long accNo, double bal) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}

