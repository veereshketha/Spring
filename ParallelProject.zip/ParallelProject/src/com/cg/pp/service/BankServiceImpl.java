package com.cg.pp.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.pp.dao.BankDAOImpl;
import com.cg.pp.dao.IBankDAO;
import com.cg.pp.dto.Account;
import com.cg.pp.dto.Customer;

public class BankServiceImpl implements IBankService{
	
	IBankDAO dao=new BankDAOImpl();

	@Override
	public long addcustDetails(long accno,Customer cus ) throws ClassNotFoundException, SQLException {
		
		dao.addcustDetails(accno,cus);
		return cus.getAccNo();
	}

	@Override
	public long addAccDetails(long accno,Account acc ) throws ClassNotFoundException, SQLException  {
		
		dao.addAccDetails(accno,acc);
		return acc.getAccno();
	}

	@Override
	public Account showBalance(Long accNo) throws ClassNotFoundException, SQLException {
		Account account=dao.showBalance(accNo);
		return account;
	}

	@Override
	public Account deposit(Long accNo,double bal) throws ClassNotFoundException, SQLException {
	Account account=dao.deposit(accNo, bal);
	return account;
	}

	@Override
	public Account withDraw(Long accNo,double bal) throws ClassNotFoundException, SQLException {
		
	Account account=dao.withDraw(accNo,bal);
		return account;
	}

	@Override
	public Account fundTransfer(Long accNo) throws ClassNotFoundException, SQLException {
		Account account=dao.fundTransfer(accNo);
		return account;
	}

	

	public boolean validateName(String s) throws ClassNotFoundException, SQLException
	{
		Pattern p=Pattern.compile("[A-Z]{1}[a-z]{3,9}");
		Matcher m=p.matcher(s)	;
		if(m.matches())
		{
			return true;
		}
		return false;
	}
	
	public boolean validateCellNo(String sl) throws ClassNotFoundException, SQLException
	{
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(sl);
		if(m.matches())
		{
			return true;
		}
		return false;

}
	
	public boolean validateAge(String h) throws ClassNotFoundException, SQLException
	{
		Pattern p=Pattern.compile("[1-9]{1}[1-9]{1}");
		Matcher m=p.matcher(h)	;
		if(m.matches())
		{
			return true;
		}
		return false;
	}
	
public boolean validateAccNO(String s2) throws ClassNotFoundException, SQLException
	{
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(s2);
		if(m.matches())
		{
			return true;
		}
		return false;
}
	@Override
	public  HashMap<Long,Account> fetchAccount() throws ClassNotFoundException, SQLException
	{
		HashMap<Long,Account> map=dao.fetchAccount();
		return map;
	}
}
