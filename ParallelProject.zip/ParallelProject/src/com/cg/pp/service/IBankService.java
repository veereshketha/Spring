package com.cg.pp.service;

import java.sql.SQLException;
import java.util.HashMap;

import com.cg.pp.dto.Account;
import com.cg.pp.dto.Customer;
import com.cg.pp.exceptions.BankException;

public interface IBankService {
	
	public long addcustDetails(long accno,Customer cus ) throws ClassNotFoundException, SQLException;
	
	public long addAccDetails(long accno,Account acc ) throws ClassNotFoundException, SQLException;
	
	public Account showBalance(Long accNo) throws ClassNotFoundException, SQLException;

	public Account deposit(Long accNo,double bal) throws ClassNotFoundException, SQLException;

	public Account withDraw(Long accNo,double bal) throws ClassNotFoundException, SQLException;

	public Account fundTransfer(Long accNo) throws ClassNotFoundException, SQLException;

	

	public boolean validateName(String s) throws ClassNotFoundException, SQLException;

	public boolean validateAge(String h) throws ClassNotFoundException, SQLException;

	public boolean validateCellNo(String sl) throws ClassNotFoundException, SQLException;

	public boolean validateAccNO(String s2) throws ClassNotFoundException, SQLException;

	public  HashMap<Long,Account> fetchAccount() throws ClassNotFoundException, SQLException;
}
