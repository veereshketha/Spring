package com.cg.pp.ui;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Scanner;
import com.cg.pp.dto.Account;
import com.cg.pp.dto.Customer;
import com.cg.pp.exceptions.BankException;
import com.cg.pp.service.IBankService;
import com.cg.pp.service.BankServiceImpl;

public class Main {
static Scanner scanner=null;
static IBankService service=null;
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	scanner=new Scanner(System.in);
	service=new BankServiceImpl();
	boolean choiceFlag=false;
	String continueChoice="";
	do {
	
	System.out.println("Welcome To XYZ Bank");
	System.out.println("1.Create Account");
	System.out.println("2.Show Balance");
	System.out.println("3.Deposit");
	System.out.println("4.Withdraw");
	System.out.println("5.Fund Transfer");
	System.out.println("6.Exit");
	
	System.out.println("Enter your choice");
	int choice=scanner.nextInt();
	switch(choice)
	{
	case 1: createAccount();
	        break;
	case 2: showBalance();
	        break;
	case 3:  toDeposit();
	        break;
	case 4:  toWithDraw();
	        break;
	case 5:  toFundTransfer();
	        break;
	
	case 6: System.out.println("Thank you"); 
		System.exit(0);
		break;
		
	default:
		choiceFlag=false;
		System.err.println("input should be 1 2 3 4 5 6");
		break;
		}
	scanner=new Scanner(System.in);
	System.out.println("Do you want to continue again[yes/no]");
	continueChoice=scanner.nextLine();
	
	}while(continueChoice.equalsIgnoreCase("yes"));
}
public static void createAccount() throws ClassNotFoundException, SQLException
{
	System.out.println("Enter customer name");
	String cusName=scanner.next();
	try
	{
	if(service.validateName(cusName)==true)
	{
		System.out.println("Enter Phone number");
		long phoneNo1=scanner.nextLong();
		String phoneNo=String.valueOf(phoneNo1);
	
		try
		{
			if(service.validateCellNo(phoneNo)==true)
			{
				System.out.println("Enter age");
				int age1=scanner.nextInt();
				String age=String.valueOf(age1);
				try
				{
					if(service.validateAge(age)==true)
					{
						
						System.out.println("Minimum balance should be maintained to create account");
						System.out.println("Enter the amount you want to deposit");
						double bal=scanner.nextDouble();
						if(bal>500)
						{
							int accNo1=(int)(Math. random() * 1364381123 + 1364381123);
							long accNo=(long)accNo1;
							Account acc=new Account(bal, accNo1,LocalDate.now());
							service.addAccDetails(accNo1, acc);
							System.out.println("Account is successfully created");
							System.out.println("Acc no:"+accNo1+ "   "+"Date:"+LocalDate.now());
							
							Customer c=new Customer(cusName, phoneNo, age1, accNo);
							service.addcustDetails(accNo1, c);
							System.out.println("Customer Details is successfully added");
						}
						else
						{
							System.out.println("Balance is below expected");
						}
					
						}
					else
					{
						throw new BankException(age1);
					}
				}catch(BankException e)
				{
					e.getStackTrace();
				}
			}
			else
			{
				throw new BankException(Long.parseLong(phoneNo));
			}
		}
		catch(BankException e)
		{
			e.getStackTrace();
		}
	}
	else
	{
	 throw new BankException(cusName);
	}}
	catch(BankException e)
	{
		e.getStackTrace();
	}
}
public static void showBalance() throws ClassNotFoundException, SQLException
{
	System.out.println("Enter account number to get balance");
	long accNo=scanner.nextLong();
	String accNo1=String.valueOf(accNo);
	try {
	if(service.validateAccNO(accNo1)==true)
	{
		HashMap<Long, Account> map=service.fetchAccount();
		try {
		if(map.containsKey(accNo))
		{
		
     Account account=service.showBalance(accNo);
	double balance=account.getBalance();
	System.out.println("Balance in the account:"+ balance);
	
}
		else
		{
			throw new BankException(accNo);
		}}catch(BankException e)
		{
			e.getStackTrace();
		}
	}
		
	else
	{
		throw new BankException(accNo);
	}
}catch(BankException e)
	{
	e.getStackTrace();
	}
}
public static void toDeposit() throws ClassNotFoundException, SQLException
{
	System.out.println("Enter account number");
	long accNo=scanner.nextLong();
	String accNo1=String.valueOf(accNo);

	if(service.validateAccNO(accNo1)==true)
		
	{
		HashMap<Long, Account> map=service.fetchAccount();
		try {
		if(map.containsKey(accNo))
		{
		System.out.println("Enter amount to be deposited");
		double amount=scanner.nextDouble();
	Account acc=service.deposit(accNo, amount);
		double balance1=acc.getBalance();
		double balance=balance1+amount;
		
		Account acc1=new Account(balance, accNo, LocalDate.now());
		System.out.println("Amount successfully deposited:"+acc1);
		
	}else
	{
		throw new BankException(accNo);
	}}catch(BankException e)
	{
		e.getStackTrace();
	}
	}
	else
	{
		System.out.println("Enter the valid account number");
	}
	}
		
	public static void toWithDraw() throws ClassNotFoundException, SQLException
{
	System.out.println("Enter account number");
	long accNo=scanner.nextLong();
	String accNo1=String.valueOf(accNo);
	try {
	if(service.validateAccNO(accNo1)==true)
		
	{
		HashMap<Long, Account> map=service.fetchAccount();
		try {
		if(map.containsKey(accNo))
		{
		System.out.println("Enter amount to be withdraw");
		double amount=scanner.nextDouble();
		Account acc=service.withDraw(accNo, amount);
		double bal=acc.getBalance();
		if(amount<(bal-500))
		{
			double balance=bal-amount;
			Account acc1=new Account(balance, accNo, LocalDate.now());
			System.out.println("Amount successfully withdrawn");
			System.out.println("Account balance:"+balance+"  "+ "Date"+LocalDate.now());
			}
	}
		else
		{
			throw new BankException(accNo);
		}}catch(BankException e)
		{
			e.getStackTrace();
		}
	}
	else
	{
		throw new BankException(accNo);
	}
}catch(BankException e)
	{
	e.getStackTrace();
	}
}
	
public static void toFundTransfer() throws ClassNotFoundException, SQLException
{
	System.out.println("Enter the sender account number");
	long accNo1=scanner.nextLong();
	System.out.println("Enter the receiver account number");
	long accNo2= scanner.nextLong();
	String accNo3=String.valueOf(accNo1);
	String accNo4=String.valueOf(accNo2);
	try {
	if((service.validateAccNO(accNo3)==true)&&(service.validateAccNO(accNo4)==true))
	{
		
		HashMap<Long, Account> map=service.fetchAccount();
		try {
		if(map.containsKey(accNo1)&&map.containsKey(accNo2))
		{
		System.out.println("Enter amount to be transfer");
		double amount=scanner.nextDouble();
		Account acc=service.fundTransfer(accNo1);
		Account acc1=service.fundTransfer(accNo2);
		double bal1=acc.getBalance();
		double bal2=acc.getBalance();
		if(amount<(bal1-500))
		{
			
			double balance2=bal2+amount;
			double balance1=bal1-amount;
		Account account1=new Account(balance1,accNo1,LocalDate.now());
			Account account2=new Account(balance2, accNo2,LocalDate.now());
			System.out.println("Amount is transferred successfully");
			System.out.println("Amount balance in sender:"+balance1+"  "+"Date"+LocalDate.now());
			System.out.println("Amount balance in receiver:"+balance2+"  "+"Date"+LocalDate.now());
		}
	}else
	{
		throw new BankException(accNo1);
	}
}catch(BankException e)
	{
	e.getStackTrace();
	}
	}
	else
	{
		throw new BankException(accNo1);
	}
}catch(BankException e)
	{
	e.getStackTrace();
	}
	}
}
