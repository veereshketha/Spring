package com.cg.pp.exceptions;

public class BankException extends Exception{

	public BankException(String name) {
	
		System.err.println("Enter only alphabets and first letter should be capital");
	}
	public BankException(Long phoneNO) {
		
		System.err.println("Invalid phone numbe");
	}
	public BankException(int age)
	{
		System.err.println("Minimum age is required");
	}
public BankException(long accNo) {
		
		System.err.println("phone number should contain only digits and minimum 10 numbers");
	}

}
