package com.cg.bean;

public class Account {
	
	private String custName;
	private String cellno;
	private String branch;
	private double balance;
	
	public Account() {
		super();
		
	}

	public Account(String custName, String cellno, String branch, double balance) {
		super();
		this.custName = custName;
		this.cellno = cellno;
		this.branch = branch;
		this.balance = balance;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCellno() {
		return cellno;
	}

	public void setCellno(String cellno) {
		this.cellno = cellno;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getBalance() {
		return balance;
	}

	public double setBalance(double balance) {
		 return this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [custName=" + custName + ", cellno=" + cellno + ", branch=" + branch + ", balance=" + balance
				+ "]";
	}
}
