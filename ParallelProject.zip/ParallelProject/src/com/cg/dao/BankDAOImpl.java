package com.cg.dao;

import java.util.Map;

import com.cg.bean.Account;
import com.cg.exception.BankingException;
import com.cg.utility.BANKUtil;

public class BankDAOImpl implements BankDAO {

	@Override
	public void addcustomer(int accno, Account ab) {
		BANKUtil.addcustomer(accno, ab);
		
	}

	@Override
	public Account showbalance(int number) throws BankingException {
		Account answer=BANKUtil.showbalance(number);
		return answer;
	}

	@Override
	public Account getAccountToAdd(int target) throws BankingException {
		
		return BANKUtil.getAccountToAdd(target);
	}

	@Override
	public Account getDetailsForWithdraw(int acc1) throws BankingException {
		
		return BANKUtil.getDetailsForWithdraw(acc1);
	}

	@Override
	public Map<String, Integer> getTransactionInfo() throws BankingException {
	
		return BANKUtil.getTrans();
	}

	@Override
	public void storeIntoTransaction(String s, Integer i) throws BankingException {
		BANKUtil.addTransaction(s, i);
	}
	
	
	

}
