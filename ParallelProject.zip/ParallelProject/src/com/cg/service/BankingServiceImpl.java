package com.cg.service;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.bean.Account;
import com.cg.dao.BankDAO;
import com.cg.dao.BankDAOImpl;
import com.cg.exception.BankingException;


public class BankingServiceImpl implements BankingService {
	
	BankDAO dao=new BankDAOImpl();

	@Override
	public void addcustomer(int accno, Account ab) {
		dao.addcustomer(accno,ab);	
	}

	@Override
	public Account showbalance(int number) throws BankingException {
		Account answer=dao.showbalance(number);
		return answer;
	}

	@Override
	public void validateBranch(String branchname) throws BankingException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, branchname)) {
			throw new BankingException("first letter should be capital and length must be in between 5 to 10");
		}	
	}

	@Override
	public void validateCell(String cellno) throws BankingException {
		String nameRegEx = "[7|8|9]{1}[0-9]{9}";
		if(!Pattern.matches(nameRegEx, cellno)) {
			throw new BankingException("mobile number should be 10 digits");
		}
	}

	@Override
	public void validateName(String custName) throws BankingException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, custName)) {
			throw new BankingException("first letter should be capital and length must be in between 5 to 10");
		}
		
	}

	@Override
	public Account getAccountToAdd(int target) throws BankingException {
		
		return dao.getAccountToAdd(target);
		
		
	}

	@Override
	public Account getDetailsForWithdraw(int acc1) throws BankingException {
		
		return dao.getDetailsForWithdraw(acc1);
	}

	@Override
	public Map<String, Integer> getTransactionInfo() throws BankingException {
		
		return dao.getTransactionInfo();
	}

	@Override
	public void storeIntoTransaction(String s, Integer i) throws BankingException {
		dao.storeIntoTransaction(s,i);
	}

	

}
