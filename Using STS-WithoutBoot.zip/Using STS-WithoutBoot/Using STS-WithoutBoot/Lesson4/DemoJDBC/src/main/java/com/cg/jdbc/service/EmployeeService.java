package com.cg.jdbc.service;

import java.util.List;

import com.cg.jdbc.bean.Employee;

public interface EmployeeService {
	public int getCount();
	public String getEmployeeName(int eid);
	public int insertRec(int eid,String enm,double esl);
	public int updateRec(int eid,String enm,double esl);
	public List getAll();
	public Employee getEmpByEid(int eid) ;
	public List<Employee> getEmployeeList() ;
}
