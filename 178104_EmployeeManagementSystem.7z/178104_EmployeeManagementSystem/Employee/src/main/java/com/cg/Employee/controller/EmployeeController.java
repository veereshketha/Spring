package com.cg.Employee.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Employee.bean.Employee;
import com.cg.Employee.service.IEmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	IEmployeeService employeeService;
	@Autowired
	Employee employee;
	/*
	 * Post Request Used
	 * http://localhost:8087/createEmployee
	 */
	@PostMapping(value="/createemployee",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Employee createEmployee(@RequestBody Employee employee) {
		Employee savedEmployee=employeeService.createEmployee(employee);
	return savedEmployee;
	}
	
	/*
	 * Put Request Used
	 * http://localhost:8087/updateEmployee/id
	 */
@PutMapping(value="/updateemployee/{id}",consumes= {MediaType.APPLICATION_JSON_VALUE})
public void updateEmployee(@RequestBody Employee employee) {
	Employee updateEmployee=employeeService.updateEmployee(employee);
	System.out.println("Employee updated successfully");
	System.out.println(updateEmployee);
	
}
/*
 * Delete Request Used
 * http://localhost:8087/deletebyemployeeid/
 */
@DeleteMapping("/deletebyemployeeid/{id}")
public String deleteById(@PathVariable String id) {
	employeeService.deleteById(id);
	return id +"Deleted";
}
/*
 * Get Request Used
 * http://localhost:8087/viewemployees
 */
@GetMapping("/viewemployees")
public List<Employee> viewEmployees(){
	return employeeService.viewEmployees();
}
/*
 * Get Request Used
 * http://localhost:8087/findbyemployeesid/
 */
@GetMapping("/findbyemployeeid/{id}")
public Employee findById(@PathVariable String id) {
	return employeeService.findById(id);
}


}
