package com.cg.Employee.service;

import java.util.List;
import java.util.Optional;

import com.cg.Employee.bean.Employee;

public interface IEmployeeService {
	public Employee createEmployee(Employee employee);
	public Employee updateEmployee(Employee employee);
	public void deleteById(String id);
	public List<Employee>viewEmployees();
	public Employee findById(String id);

}
