package com.cg.Employee.bean;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Employee")
@Component
public class Employee {
	@Id
	private String emp_id;
	private String name;
	private String designtion;
	private String dept_name;
	private int salary;
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesigntion() {
		return designtion;
	}
	public void setDesigntion(String designtion) {
		this.designtion = designtion;
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Employee(String emp_id, String name, String designtion, String dept_name, int salary) {
		super();
		this.emp_id = emp_id;
		this.name = name;
		this.designtion = designtion;
		this.dept_name = dept_name;
		this.salary = salary;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", name=" + name + ", designtion=" + designtion + ", dept_name="
				+ dept_name + ", salary=" + salary + "]";
	}

}
