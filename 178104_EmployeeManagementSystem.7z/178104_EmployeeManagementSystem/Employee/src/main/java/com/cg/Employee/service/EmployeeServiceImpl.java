package com.cg.Employee.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Employee.bean.Employee;
import com.cg.Employee.dao.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements IEmployeeService{
	@Autowired 
	private EmployeeRepository employeerepository;         //creating object of repository interface

	@Override
	public Employee createEmployee(Employee employee) {      //create new record
		// TODO Auto-generated method stub
		return employeerepository.save(employee);
	}

	@Override
	public Employee updateEmployee(Employee employee) {        //update the existing employee
		// TODO Auto-generated method stub
		return employeerepository.save(employee);
	}

	@Override
	public void deleteById(String id) {                        //delete record from database by given a particular id
		// TODO Auto-generated method stub
		employeerepository.deleteById(id);
		
	}

	@Override
	public List<Employee> viewEmployees() {                  //display all the employee given in records
		// TODO Auto-generated method stub
		return employeerepository.findAll();
	}

	@Override
	public Employee findById(String id) {                    //display the information of employee by giving particular id
		// TODO Auto-generated method stub
		return employeerepository.findById(id).get();
	}

	
	

}
