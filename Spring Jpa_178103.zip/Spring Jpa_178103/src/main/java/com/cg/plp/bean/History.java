package com.cg.plp.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name="transaction")
@Component
@Scope("prototype")
public class History{


	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "tid")
	@SequenceGenerator(sequenceName="tid_seq", name = "tid")
	private int tid;
	public BankAccount getCustomer() {
		return customer;
	}

	public void setCustomer(BankAccount customer) {
		this.customer = customer;
	}

	private String mobileNo;
	private String type;
	private double amount, balance;
	
	@ManyToOne
	@JoinColumn(name="customerId")
	private BankAccount customer;

	
	public History() {
		super();
	}

	public History(String mobileNo, String type, double amount,
			double balance) {
		this.mobileNo = mobileNo;
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	// getters setters
	public String getMobileNo() {
		return mobileNo;
	}

	public String getType() {
		return type;
	}

	public double getAmount() {
		return amount;
	}

	public double getBalance() {
		return balance;
	}
	

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "mobileNo=" + mobileNo
				+ ", type=" + type + ", amount=" + amount + ", balance="
				+ balance+ "\n";
	}

	
}
