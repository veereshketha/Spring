package com.cg.plp.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.bean.History;
import com.cg.plp.exception.CustomerExists;
import com.cg.plp.exception.CustomerNotFoundException;
import com.cg.plp.exception.InsufficientBalanceException;

@Repository("customerDAO")
public class BankDaoImpl implements BankDAO {

	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager manager;

	@Autowired
	private ApplicationContext context;

	@Override
	public BankAccount createCustomer(BankAccount customer) throws CustomerExists {
		TypedQuery<Long> query = manager.createQuery(
				"SELECT COUNT(cust.customerId) FROM Customer cust where cust.mobileNumber=:pMob", Long.class);
		query.setParameter("pMob", customer.getMobileNumber());
		long count = query.getSingleResult();

		if (count < 1) {
			
			History recordTrans = (History) context.getBean(History.class);
			recordTrans.setMobileNo(customer.getMobileNumber());
			recordTrans.setType("CR");
			recordTrans.setAmount(customer.getBalance());
			recordTrans.setBalance(customer.getBalance());
			
			recordTrans.setCustomer(customer);
			customer.getTransactionList().add(recordTrans);
			manager.persist(customer);
			
			return customer;
		} else {
			throw new CustomerExists("Customer Already Exists");
		}
	}

	@Override
	public String withDraw(BankAccount customer, double amount) throws InsufficientBalanceException {
		if (amount <= customer.getBalance() - 100) {
			customer.setBalance(customer.getBalance() - amount);
			
			History recordTrans = (History) context.getBean(History.class);
			recordTrans.setMobileNo(customer.getMobileNumber());
			recordTrans.setType("DB");
			recordTrans.setAmount(amount);
			recordTrans.setBalance(customer.getBalance());
			
			recordTrans.setCustomer(customer);
			customer.getTransactionList().add(recordTrans);
			manager.merge(customer);
			
			return "Rs." + amount + " debited from account " + customer.getCustomerId() + " on " + LocalDateTime.now()
					+ "\nNew Balance is Rs." + customer.getBalance();
		} else {
			throw new InsufficientBalanceException("You Have Insufficient Fund.");
		}
	}

	@Override
	public String deposit(BankAccount customer, double amount) throws CustomerNotFoundException {

		customer.setBalance(customer.getBalance() + amount);
		
		History recordTrans = (History) context.getBean(History.class);
		recordTrans.setMobileNo(customer.getMobileNumber());
		recordTrans.setType("CR");
		recordTrans.setAmount(amount);
		recordTrans.setBalance(customer.getBalance());
		
		recordTrans.setCustomer(customer);
		customer.getTransactionList().add(recordTrans);
		manager.merge(customer);
		
		return "Rs." + amount + " credited on account " + customer.getCustomerId() + " on " + LocalDateTime.now()
				+ "\nNew Balance is Rs." + customer.getBalance();
	}

	@Override
	public BankAccount checkUser(String username, String password) throws CustomerNotFoundException {
		TypedQuery<BankAccount> query = manager.createQuery(
				"Select cust FROM Customer cust WHERE cust.mobileNumber=:pMob AND cust.password=:pPass",
				BankAccount.class);
		query.setParameter("pMob", username);
		query.setParameter("pPass", password);
		if (query.getResultList().size() != 0) {
			BankAccount customer = query.getSingleResult();
			return customer;
		} else {
			throw new CustomerNotFoundException("Invalid Credentials");
		}
	}

	@Override
	public List<History> printTransaction(BankAccount customer) {
		List<History> list = new ArrayList<>(customer.getTransactionList());
		return list;
	}

	@Override
	public BankAccount isValidUser(String mobileNumber) throws CustomerNotFoundException {

		TypedQuery<BankAccount> query = manager.createQuery("SELECT cust FROM Customer cust WHERE cust.mobileNumber=:pMob",
				BankAccount.class);
		query.setParameter("pMob", mobileNumber);
		if (query.getResultList().size() != 0) {
			BankAccount customer = query.getSingleResult();
			return customer;
		} else {
			throw new CustomerNotFoundException("No User Found With Given Mobile Number");
		}
	}

	@Override
	public double checkBalance(BankAccount customer) {
		return customer.getBalance();
	}

}