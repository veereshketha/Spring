package com.cg.plp.dao;

import java.util.List;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.bean.History;
import com.cg.plp.exception.CustomerExists;
import com.cg.plp.exception.CustomerNotFoundException;
import com.cg.plp.exception.InsufficientBalanceException;

public interface BankDAO {

	BankAccount createCustomer(BankAccount customer) throws CustomerExists;

	String withDraw(BankAccount customer, double amount)	throws InsufficientBalanceException;

	String deposit(BankAccount customer, double amount) throws CustomerNotFoundException;

	BankAccount checkUser(String username, String password) throws CustomerNotFoundException;

	List<History> printTransaction(BankAccount customer);

	BankAccount isValidUser(String mobileNumber) throws CustomerNotFoundException;
	
	double checkBalance(BankAccount customer);
}
