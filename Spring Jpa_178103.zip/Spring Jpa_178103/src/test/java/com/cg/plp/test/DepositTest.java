package com.cg.plp.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.plp.bean.BankAccount;
import com.cg.plp.exception.CustomerExists;
import com.cg.plp.exception.CustomerNotFoundException;
import com.cg.plp.service.BankServiceImpl;
import com.cg.plp.service.BankService;

public class DepositTest {
	BankService service = null;

	@Before
	public void setUp() throws Exception {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		service = (BankService) ctx.getBean("service");
	}

	// right inputs
	@Test
	public void checkDeposit() {
		try {
			BankAccount customer = service.checkUser("8286703935", "password");
			String result = service.deposit(customer, 2000);
			System.out.println(result);
			assertNotNull(result);
		}catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print no user as user don't exists in console
	@Test
	public void checkDeposit2() {
		try {
			BankAccount customer = service.checkUser("11111935", "password");
			String result = service.deposit(customer, 9000);
			System.out.println(result);
			assertNotNull(result);
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
